#!/usr/bin/env python3
"""Convert the official MIT 'DomandeB.pdf' into content/questions.json,
content/chapters.json and assets/signs/*.jpg.

Usage: python convert_pdf.py DomandeB.pdf
Needs: pdfplumber, poppler-utils (pdfimages).
"""
import hashlib, json, re, shutil, subprocess, sys, tempfile
from pathlib import Path
import pdfplumber

ROOT = Path(__file__).resolve().parent
CONTENT = ROOT / "content"
SIGNS = ROOT.parent / "assets" / "signs"
NUM_X, TEXT_X0, TEXT_X1, ANS_X0, IMG_X0 = 60, 70, 350, 350, 455


_cache = {}

def save_image(stream):
    """Save the JPEG bytes of a PDF image stream; return its (deduplicated) file name."""
    oid = stream.objid
    if oid in _cache:
        return _cache[oid]
    filt = stream.get_any(("Filter", "F"))
    data = stream.get_rawdata()
    name = None
    if filt is not None and "DCT" in str(filt):
        h = hashlib.md5(data).hexdigest()[:12]
        name = f"{h}.jpg"
        SIGNS.mkdir(parents=True, exist_ok=True)
        if not (SIGNS / name).exists():
            (SIGNS / name).write_bytes(data)
    _cache[oid] = name
    return name


def lines_of(words, tol=3):
    rows = []
    for w in sorted(words, key=lambda w: (round(w["top"]), w["x0"])):
        if rows and abs(rows[-1][0] - w["top"]) <= tol:
            rows[-1][1].append(w)
        else:
            rows.append([w["top"], [w]])
    return rows


def main(pdf_path):
    questions, chapters = [], {}
    group = None  # current heading text
    group_no = None

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            words = page.extract_words()
            imgs = [i for i in page.images if i["x0"] >= IMG_X0]
            # heading(s) on this page
            hdr_tops = [w["top"] for w in words if w["text"] == "Quesito" and w["x0"] < 40]
            num_hdr = sorted(w["top"] for w in words if w["text"] == "Numero" and w["x0"] < 40)
            events = []  # (top, kind, payload)
            for ht in hdr_tops:
                end = next((n for n in num_hdr if n > ht), ht + 60)
                hw = [w for w in words if ht - 2 <= w["top"] < end - 2 and w["x0"] < 560]
                text = " ".join(" ".join(w["text"] for w in l[1]) for l in lines_of(hw))
                m = re.match(r"Quesito n° (\d+) - (.*)", text)
                if m:
                    events.append((ht, "group", (m.group(1), m.group(2).strip())))
            # question rows
            body_top = max([n for n in num_hdr] + [0])
            starts = sorted(
                w["top"] for w in words
                if w["x0"] < NUM_X and re.fullmatch(r"\d{3,6}", w["text"]) and w["top"] > 10
            )
            # rows are bounded by successive numbers; group headings split them further
            all_tops = sorted(set(starts + [e[0] for e in events]))
            for ev in sorted(events):
                pass
            bounds = all_tops + [page.height]
            group_events = {e[0]: e[2] for e in events}
            for i, top in enumerate(all_tops):
                if top in group_events:
                    group_no, group = group_events[top]
                    continue
                nxt = bounds[i + 1]
                nw = [w for w in words if w["x0"] < NUM_X and re.fullmatch(r"\d{3,6}", w["text"]) and abs(w["top"] - top) < 2]
                if not nw or group is None:
                    continue
                qid = int(nw[0]["text"])
                seg = [w for w in words if top - 2 <= w["top"] < nxt - 2]
                text = " ".join(w["text"] for w in sorted(seg, key=lambda w: (round(w["top"]), w["x0"]))
                                if TEXT_X0 <= w["x0"] < TEXT_X1)
                ans = [w["text"] for w in seg if w["x0"] >= ANS_X0 and w["text"] in ("VERO", "FALSO") and w["x0"] < IMG_X0]
                img = next((save_image(i["stream"]) for i in imgs if top - 8 <= i["top"] < nxt - 2), None)
                if not ans:
                    continue
                if group not in chapters:
                    chapters[group] = len(chapters) + 1
                questions.append({
                    "id": qid, "chapter_id": chapters[group], "group_no": int(group_no),
                    "text_it": re.sub(r"\s+", " ", text).strip(),
                    "is_true": ans[0] == "VERO", "image": img,
                })

    # Chapter titles: part before the first ';' is the short name
    ch_list = []
    for full, cid in chapters.items():
        title = full.split(";")[0].split(" - ")[0].strip()
        ch_list.append({"id": cid, "title_it": title, "title_full": full, "title_ur": None, "sort_order": cid})
    CONTENT.mkdir(exist_ok=True)
    (CONTENT / "questions.json").write_text(json.dumps(questions, ensure_ascii=False, indent=1), encoding="utf-8")
    (CONTENT / "chapters.json").write_text(json.dumps(ch_list, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"questions={len(questions)} chapters={len(ch_list)} signs={len(set(q['image'] for q in questions if q['image']))}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: python convert_pdf.py DomandeB.pdf")
    main(sys.argv[1])
