# Content pipeline

1. Put the official quiz data into `content/questions.json`
   (fields: id, chapter_id, text_it, is_true, image). Keep `content/chapters.json` in sync
   with the chapters you actually use. The 5 questions included are only samples
   for testing.
2. `python enrich.py` -> fills text_ur, explanation_it, explanation_ur (needs ANTHROPIC_API_KEY).
   Resumable. Items are flagged "needs_review".
3. Have a native Urdu speaker review the flagged items (start with the most-failed questions).
4. `python build_db.py` -> writes ../assets/db/patente.db, which the Flutter app loads.

Add terms to `content/glossary.json` so Urdu stays consistent.
