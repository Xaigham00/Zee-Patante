#!/usr/bin/env python3
"""Build assets/db/patente.db from schema.sql + content/*.json.

Usage: python build_db.py
Optional files: content/lessons.json (same fields as the lessons table).
"""
import json, sqlite3, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCHEMA = ROOT.parent / "assets" / "db" / "schema.sql"
OUT = ROOT.parent / "assets" / "db" / "patente.db"
CONTENT = ROOT / "content"


def load(name, required=True):
    p = CONTENT / name
    if not p.exists():
        if required:
            sys.exit(f"Missing {p}")
        return []
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    chapters, questions = load("chapters.json"), load("questions.json")
    lessons = load("lessons.json", required=False)

    if OUT.exists():
        OUT.unlink()
    db = sqlite3.connect(OUT)
    db.executescript(SCHEMA.read_text(encoding="utf-8"))

    chapter_ids = {c["id"] for c in chapters}
    db.executemany(
        "INSERT INTO chapters VALUES (?,?,?,?)",
        [(c["id"], c["title_it"], c.get("title_ur"), c["sort_order"]) for c in chapters],
    )
    db.executemany(
        "INSERT INTO lessons VALUES (?,?,?,?,?,?,?)",
        [(l["id"], l["chapter_id"], l["title_it"], l.get("title_ur"),
          l["body_it"], l.get("body_ur"), l["sort_order"]) for l in lessons],
    )

    bad = [q["id"] for q in questions if q["chapter_id"] not in chapter_ids]
    if bad:
        sys.exit(f"Questions with unknown chapter_id: {bad[:10]}")

    db.executemany(
        "INSERT INTO questions VALUES (?,?,?,?,?,?,?,?)",
        [(q["id"], q["chapter_id"], q["text_it"], q.get("text_ur"),
          1 if q["is_true"] else 0, q.get("image"),
          q.get("explanation_it"), q.get("explanation_ur")) for q in questions],
    )
    db.commit()

    n = len(questions)
    miss_ur = sum(1 for q in questions if not q.get("text_ur"))
    miss_ex = sum(1 for q in questions if not q.get("explanation_it"))
    miss_exur = sum(1 for q in questions if not q.get("explanation_ur"))
    print(f"Built {OUT}")
    print(f"chapters={len(chapters)} lessons={len(lessons)} questions={n}")
    print(f"missing: text_ur={miss_ur} explanation_it={miss_ex} explanation_ur={miss_exur}")
    db.close()


if __name__ == "__main__":
    main()
