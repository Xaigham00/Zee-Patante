#!/usr/bin/env python3
"""Fill in missing Urdu text and explanations with Claude, in resumable batches.

Setup:  pip install -r requirements.txt
        export ANTHROPIC_API_KEY=...        (Windows: set ANTHROPIC_API_KEY=...)
Run:    python enrich.py                    # all chapters
        python enrich.py --chapter 5        # one chapter
        python enrich.py --batch 10 --limit 50   # test on 50 questions

Only questions with a missing field are processed, and the file is saved after
every batch, so you can stop and resume at any time. Filled questions get
"needs_review": true -- have a native Urdu speaker check them before release.
"""
import argparse, json, os, re, sys, time
from pathlib import Path
import anthropic

ROOT = Path(__file__).resolve().parent
QFILE = ROOT / "content" / "questions.json"
CFILE = ROOT / "content" / "chapters.json"
GFILE = ROOT / "content" / "glossary.json"
MODEL = os.environ.get("CLAUDE_MODEL", "claude-sonnet-5-5")
FIELDS = ("text_ur", "explanation_it", "explanation_ur")

SYSTEM = """You are an expert Italian driving instructor (autoscuola) and a professional \
Italian-to-Urdu translator. You help Urdu-speaking learners pass the Italian \
patente B theory exam.

For each true/false question you receive, produce:
- text_ur: a clear, natural Urdu translation of the question. Keep the exact meaning \
(do NOT change a true statement into a false one or vice versa).
- explanation_it: 1-3 short sentences in simple Italian explaining WHY the correct \
answer (given in is_true) is correct, based on the rules of the Italian Codice della Strada.
- explanation_ur: the same explanation in simple Urdu.

Rules:
- The correct answer is given as is_true. Your explanation must agree with it.
- Do NOT cite article numbers or exact figures unless you are certain; prefer the general rule.
- Use simple everyday Urdu. For road signs and technical terms put the Italian term in \
brackets the first time, e.g. اوورٹیک (sorpasso). Follow the glossary when a term appears.
- Output ONLY a JSON array, no markdown fences, with one object per question: \
{"id": <int>, "text_ur": "...", "explanation_it": "...", "explanation_ur": "..."}"""


def translate_chapters(client):
    """Fill missing Urdu chapter titles (one small call)."""
    chapters = json.loads(CFILE.read_text(encoding="utf-8"))
    todo = [c for c in chapters if not c.get("title_ur")]
    if not todo:
        return
    payload = [{"id": c["id"], "title_it": c["title_it"]} for c in todo]
    msg = client.messages.create(
        model=MODEL, max_tokens=4000,
        system="Translate these Italian driving-theory chapter titles into clear Urdu. "
               "Output ONLY a JSON array of {\"id\": int, \"title_ur\": str}.",
        messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
    )
    by_id = {r["id"]: r["title_ur"] for r in parse_json(msg.content[0].text)}
    for c in chapters:
        if c["id"] in by_id:
            c["title_ur"] = by_id[c["id"]]
    CFILE.write_text(json.dumps(chapters, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"translated {len(by_id)} chapter titles")


def needs_work(q):
    return any(not q.get(f) for f in FIELDS)


def parse_json(text):
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    return json.loads(text)


def call(client, batch, chapters, glossary):
    payload = [
        {"id": q["id"], "chapter": chapters.get(q["chapter_id"], ""),
         "text_it": q["text_it"], "is_true": q["is_true"],
         "has_image": bool(q.get("image"))}
        for q in batch
    ]
    msg = client.messages.create(
        model=MODEL,
        max_tokens=8000,
        system=SYSTEM + "\n\nGlossary (Italian -> Urdu):\n" + json.dumps(glossary, ensure_ascii=False),
        messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
    )
    return parse_json(msg.content[0].text)


def save(questions):
    tmp = QFILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(questions, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(QFILE)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chapter", type=int)
    ap.add_argument("--batch", type=int, default=10)
    ap.add_argument("--limit", type=int)
    args = ap.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("Set ANTHROPIC_API_KEY first.")

    questions = json.loads(QFILE.read_text(encoding="utf-8"))
    chapters = {c["id"]: c["title_it"] for c in json.loads(CFILE.read_text(encoding="utf-8"))}
    glossary = json.loads(GFILE.read_text(encoding="utf-8")) if GFILE.exists() else {}
    by_id = {q["id"]: q for q in questions}

    todo = [q for q in questions if needs_work(q)
            and (args.chapter is None or q["chapter_id"] == args.chapter)]
    if args.limit:
        todo = todo[: args.limit]
    print(f"{len(todo)} questions to process (model: {MODEL})")

    client = anthropic.Anthropic()
    translate_chapters(client)
    for i in range(0, len(todo), args.batch):
        batch = todo[i : i + args.batch]
        for attempt in range(3):
            try:
                results = call(client, batch, chapters, glossary)
                break
            except Exception as e:
                print(f"  attempt {attempt+1} failed: {e}")
                time.sleep(3 * (attempt + 1))
        else:
            print("  skipping batch after 3 failures")
            continue

        ok = 0
        for r in results:
            q = by_id.get(r.get("id"))
            if not q:
                continue
            for f in FIELDS:
                if not q.get(f) and r.get(f):
                    q[f] = r[f].strip()
            q["needs_review"] = True
            ok += 1
        save(questions)
        print(f"  {i + len(batch)}/{len(todo)} done ({ok} updated)")

    print("Finished. Now run: python build_db.py")


if __name__ == "__main__":
    main()
