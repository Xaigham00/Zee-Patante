# Patente App (Flutter)

## Structure
- assets/db/schema.sql    -> database schema
- assets/db/patente.db    -> prebuilt DB (you generate this from the content pipeline)
- assets/signs/           -> road sign images
- lib/data/models.dart, database_helper.dart, language_provider.dart
- lib/widgets_bilingual_text.dart -> Italian/Urdu display widget

## Next
1. Build patente.db from schema.sql + official quiz data
2. Screens: Home, Syllabus, Quiz, Exam (30 q, 20 min, max 3 errors), Results, Progress
3. Language toggle button in the app bar (LangMode: Italian / Urdu / Both)
