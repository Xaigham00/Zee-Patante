import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'data/language_provider.dart';

/// Shared colours for the whole app.
class AppColors {
  static const navy = Color(0xFF1E2A5E);
  static const navy2 = Color(0xFF2B4396);
  static const green = Color(0xFF1B7F3B);
  static const greenDark = Color(0xFF125C2A);
  static const red = Color(0xFFD32F2F);
  static const redDark = Color(0xFF9A2020);
}

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.green, brightness: b),
    scaffoldBackgroundColor:
        dark ? const Color(0xFF0F172A) : const Color(0xFFEEF2F6),
  );
  return base.copyWith(
    textTheme: GoogleFonts.nunitoTextTheme(base.textTheme),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF1E293B) : Colors.white,
      indicatorColor: AppColors.green.withOpacity(dark ? 0.35 : 0.15),
    ),
  );
}

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

/// Navy gradient app bar used on every screen.
class GradientAppBar extends StatelessWidget implements PreferredSizeWidget {
  final Widget title;
  final List<Widget> actions;
  final PreferredSizeWidget? bottom;
  const GradientAppBar(
      {super.key, required this.title, this.actions = const [], this.bottom});

  @override
  Size get preferredSize =>
      Size.fromHeight(kToolbarHeight + (bottom?.preferredSize.height ?? 0));

  @override
  Widget build(BuildContext context) => AppBar(
        title: title,
        actions: actions,
        bottom: bottom,
        centerTitle: false,
        foregroundColor: Colors.white,
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        titleTextStyle: const TextStyle(
            fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white),
        flexibleSpace: const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [AppColors.navy, AppColors.navy2],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight),
          ),
        ),
      );
}

/// White rounded card with a soft shadow.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;
  final VoidCallback? onTap;
  final Color? borderColor;
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.margin = EdgeInsets.zero,
    this.onTap,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final radius = BorderRadius.circular(18);
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: radius,
        border: borderColor == null
            ? null
            : Border.all(color: borderColor!, width: 2),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(dark ? 0.35 : 0.08),
              blurRadius: 12,
              offset: const Offset(0, 4)),
        ],
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            onTap: onTap,
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );
  }
}

/// Small rounded label, e.g. "Domanda 3/30".
class Pill extends StatelessWidget {
  final String text;
  final Color? color;
  final Color? textColor;
  final IconData? icon;
  const Pill(this.text, {super.key, this.color, this.textColor, this.icon});

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final fg = textColor ?? (dark ? Colors.white : const Color(0xFF334155));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color ?? (dark ? const Color(0xFF334155) : const Color(0xFFE8EDF3)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 16, color: fg),
          const SizedBox(width: 6),
        ],
        Text(text,
            style: TextStyle(
                fontSize: 13, fontWeight: FontWeight.w800, color: fg)),
      ]),
    );
  }
}

/// Big rounded button with a darker "3D" bottom edge (VERO / FALSO / Avanti).
class ChunkyButton extends StatelessWidget {
  final Widget child;
  final Color color;
  final Color edge;
  final VoidCallback? onPressed;
  final double opacity;
  const ChunkyButton({
    super.key,
    required this.child,
    required this.color,
    required this.edge,
    required this.onPressed,
    this.opacity = 1,
  });

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: opacity,
        child: Container(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: edge, offset: const Offset(0, 5))],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onPressed,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 18),
                child: DefaultTextStyle.merge(
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5),
                  child: IconTheme.merge(
                    data: const IconThemeData(color: Colors.white),
                    child: Center(child: child),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

/// Small stat box: icon + label on top, big number below.
/// Label follows the app language toggle (Italian / Urdu / both).
class StatTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String labelIt, labelUr;
  final int value;
  final bool onDark; // translucent style for use on the green card
  const StatTile({
    super.key,
    required this.icon,
    required this.color,
    required this.labelIt,
    required this.labelUr,
    required this.value,
    this.onDark = false,
  });

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    final dark = isDark(context);
    final textColor =
        onDark ? Colors.white : (dark ? Colors.white : const Color(0xFF1E293B));
    final bg = onDark
        ? Colors.white.withOpacity(0.16)
        : (dark ? const Color(0xFF334155) : const Color(0xFFF1F5F9));
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 14, color: onDark ? Colors.white : color),
          const SizedBox(width: 3),
          Flexible(
            child: Text(lang.showIt ? labelIt : labelUr,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: textColor)),
          ),
        ]),
        const SizedBox(height: 2),
        Text('$value',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: onDark ? Colors.white : color)),
      ]),
    );
  }
}

/// The four Giuste / Sbagliate / Da fare / Totale tiles in a row.
class StatRow extends StatelessWidget {
  final int correct, wrong, todo, total;
  final bool onDark;
  const StatRow({
    super.key,
    required this.correct,
    required this.wrong,
    required this.todo,
    required this.total,
    this.onDark = false,
  });

  @override
  Widget build(BuildContext context) {
    Widget t(IconData i, Color c, String it, String ur, int v) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: StatTile(
                icon: i, color: c, labelIt: it, labelUr: ur, value: v, onDark: onDark),
          ),
        );
    return Row(children: [
      t(Icons.check_circle, AppColors.green, 'Giuste', 'درست', correct),
      t(Icons.cancel, AppColors.red, 'Sbagl.', 'غلط', wrong),
      t(Icons.radio_button_unchecked, const Color(0xFF64748B), 'Da fare',
          'باقی', todo),
      t(Icons.format_list_numbered, AppColors.navy2, 'Totale', 'کل', total),
    ]);
  }
}

/// Thin rounded progress bar.
class SoftProgress extends StatelessWidget {
  final double value;
  final bool onDark;
  const SoftProgress(this.value, {super.key, this.onDark = false});

  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: LinearProgressIndicator(
          value: value.clamp(0.0, 1.0),
          minHeight: 8,
          backgroundColor: onDark
              ? Colors.white.withOpacity(0.25)
              : (isDark(context)
                  ? const Color(0xFF334155)
                  : const Color(0xFFE2E8F0)),
          valueColor: AlwaysStoppedAnimation(
              onDark ? Colors.white : AppColors.green),
        ),
      );
}
