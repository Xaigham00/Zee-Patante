enum LangMode { italian, urdu, both }

class Chapter {
  final int id, sortOrder;
  final String titleIt;
  final String? titleUr;
  Chapter(this.id, this.titleIt, this.titleUr, this.sortOrder);
  factory Chapter.fromMap(Map<String, Object?> m) => Chapter(
      m['id'] as int, m['title_it'] as String, m['title_ur'] as String?, m['sort_order'] as int);
}

class Question {
  final int id, chapterId;
  final String textIt;
  final String? textUr, image, explanationIt, explanationUr;
  final bool isTrue;
  Question({
    required this.id, required this.chapterId, required this.textIt,
    this.textUr, required this.isTrue, this.image,
    this.explanationIt, this.explanationUr,
  });
  factory Question.fromMap(Map<String, Object?> m) => Question(
        id: m['id'] as int,
        chapterId: m['chapter_id'] as int,
        textIt: m['text_it'] as String,
        textUr: m['text_ur'] as String?,
        isTrue: (m['is_true'] as int) == 1,
        image: m['image'] as String?,
        explanationIt: m['explanation_it'] as String?,
        explanationUr: m['explanation_ur'] as String?,
      );
}

/// Progress counters for a chapter (or the whole course).
/// correct/wrong = result of the LAST attempt of each question.
class Stats {
  final int total, correct, wrong;
  const Stats(this.total, this.correct, this.wrong);
  int get todo => total - correct - wrong;
  double get done => total == 0 ? 0 : (correct + wrong) / total;
  static Stats sum(Iterable<Stats> all) => Stats(
      all.fold(0, (a, s) => a + s.total),
      all.fold(0, (a, s) => a + s.correct),
      all.fold(0, (a, s) => a + s.wrong));
}

class ExamResult {
  final int errors, durationSec;
  ExamResult(this.errors, this.durationSec);
  bool get passed => errors <= 3;
}
