import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class LanguageProvider extends ChangeNotifier {
  LangMode mode = LangMode.both;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    mode = LangMode.values[p.getInt('lang_mode') ?? 2];
    notifyListeners();
  }

  Future<void> setMode(LangMode m) async {
    mode = m;
    notifyListeners();
    (await SharedPreferences.getInstance()).setInt('lang_mode', m.index);
  }

  bool get showIt => mode != LangMode.urdu;
  bool get showUr => mode != LangMode.italian;
}
