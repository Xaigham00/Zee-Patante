import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'models.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final instance = DatabaseHelper._();
  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  // Copies the prebuilt assets/db/patente.db on first launch.
  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    final path = join(dir, 'patente.db');
    if (!await File(path).exists()) {
      await Directory(dirname(path)).create(recursive: true);
      final data = await rootBundle.load('assets/db/patente.db');
      await File(path).writeAsBytes(data.buffer.asUint8List(), flush: true);
    }
    return openDatabase(path);
  }

  Future<List<Chapter>> chapters() async {
    final rows = await (await db).query('chapters', orderBy: 'sort_order');
    return rows.map(Chapter.fromMap).toList();
  }

  /// Per-chapter totals plus how many were last answered right / wrong.
  Future<Map<int, Stats>> chapterStats() async {
    final rows = await (await db).rawQuery('''
      SELECT q.chapter_id AS cid, COUNT(*) AS total,
        SUM(CASE WHEN p.last_correct = 1 THEN 1 ELSE 0 END) AS correct,
        SUM(CASE WHEN p.last_correct = 0 THEN 1 ELSE 0 END) AS wrong
      FROM questions q LEFT JOIN progress p ON p.question_id = q.id
      GROUP BY q.chapter_id''');
    return {
      for (final r in rows)
        r['cid'] as int: Stats((r['total'] as num).toInt(),
            (r['correct'] as num?)?.toInt() ?? 0, (r['wrong'] as num?)?.toInt() ?? 0)
    };
  }

  /// Up to [perChapter] distinct sign images per chapter, for the card banners.
  Future<Map<int, List<String>>> chapterImages({int perChapter = 4}) async {
    final rows = await (await db).rawQuery('''
      SELECT chapter_id AS cid, image FROM questions
      WHERE image IS NOT NULL AND image != ''
      GROUP BY chapter_id, image ORDER BY chapter_id, MIN(id)''');
    final out = <int, List<String>>{};
    for (final r in rows) {
      final list = out.putIfAbsent(r['cid'] as int, () => []);
      if (list.length < perChapter) list.add(r['image'] as String);
    }
    return out;
  }

  Future<List<Question>> questionsByChapter(int chapterId) async {
    final rows = await (await db)
        .query('questions', where: 'chapter_id = ?', whereArgs: [chapterId]);
    return rows.map(Question.fromMap).toList();
  }

  // Exam: 30 random questions.
  Future<List<Question>> examQuestions({int count = 30}) async {
    final rows = await (await db)
        .rawQuery('SELECT * FROM questions ORDER BY RANDOM() LIMIT ?', [count]);
    return rows.map(Question.fromMap).toList();
  }

  // Practice the questions the user got wrong.
  Future<List<Question>> mistakes() async {
    final rows = await (await db).rawQuery('''
      SELECT q.* FROM questions q
      JOIN progress p ON p.question_id = q.id
      WHERE p.last_correct = 0''');
    return rows.map(Question.fromMap).toList();
  }

  Future<void> saveAnswer(int questionId, bool correct) async {
    final d = await db;
    await d.rawInsert('''
      INSERT INTO progress (question_id, attempts, correct_count, last_correct, last_at)
      VALUES (?, 1, ?, ?, ?)
      ON CONFLICT(question_id) DO UPDATE SET
        attempts = attempts + 1,
        correct_count = correct_count + excluded.correct_count,
        last_correct = excluded.last_correct,
        last_at = excluded.last_at''',
        [questionId, correct ? 1 : 0, correct ? 1 : 0,
         DateTime.now().millisecondsSinceEpoch]);
  }

  Future<void> saveExam(ExamResult r, Map<int, bool?> answers,
      Map<int, bool> correctness) async {
    final d = await db;
    await d.transaction((txn) async {
      final id = await txn.insert('exams', {
        'taken_at': DateTime.now().millisecondsSinceEpoch,
        'total': answers.length,
        'errors': r.errors,
        'passed': r.passed ? 1 : 0,
        'duration_sec': r.durationSec,
      });
      for (final e in answers.entries) {
        await txn.insert('exam_answers', {
          'exam_id': id,
          'question_id': e.key,
          'answer': e.value == null ? null : (e.value! ? 1 : 0),
          'correct': (correctness[e.key] ?? false) ? 1 : 0,
        });
      }
    });
  }

  Future<void> toggleBookmark(int questionId) async {
    final d = await db;
    final n = await d.delete('bookmarks',
        where: 'question_id = ?', whereArgs: [questionId]);
    if (n == 0) await d.insert('bookmarks', {'question_id': questionId});
  }
}
