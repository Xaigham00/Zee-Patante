import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'database_helper.dart';

/// Free, on-device Italian -> Urdu translation (Google ML Kit).
/// The two language models (about 30 MB each) are downloaded once, then it
/// works offline. Every translation is saved in the local database, so each
/// text is translated only once.
class TranslatorService {
  TranslatorService._();
  static final instance = TranslatorService._();

  final Map<String, String> _memory = {};
  OnDeviceTranslator? _translator;
  Future<bool>? _preparing;
  Future<void> _queue = Future.value();

  /// Start downloading the language models early (safe to call many times).
  Future<void> warmUp() async {
    await _prepare();
  }

  Future<bool> _prepare() => _preparing ??= _doPrepare();

  Future<bool> _doPrepare() async {
    try {
      final manager = OnDeviceTranslatorModelManager();
      for (final lang in [TranslateLanguage.italian, TranslateLanguage.urdu]) {
        final code = lang.bcpCode;
        if (!await manager.isModelDownloaded(code)) {
          final ok = await manager.downloadModel(code, isWifiRequired: false);
          if (!ok) throw Exception('Model download failed: $code');
        }
      }
      _translator = OnDeviceTranslator(
        sourceLanguage: TranslateLanguage.italian,
        targetLanguage: TranslateLanguage.urdu,
      );
      return true;
    } catch (_) {
      _preparing = null; // try again next time
      return false;
    }
  }

  /// Returns the Urdu translation, or null if it is not available
  /// (for example the models could not be downloaded yet).
  Future<String?> translate(String text) {
    final hit = _memory[text];
    if (hit != null) return Future.value(hit);
    // One translation at a time keeps the phone responsive.
    final job = _queue.then((_) => _run(text));
    _queue = job.then((_) {}, onError: (_) {});
    return job;
  }

  Future<String?> _run(String text) async {
    try {
      final memory = _memory[text];
      if (memory != null) return memory;

      final saved = await DatabaseHelper.instance.cachedTranslation(text);
      if (saved != null && saved.isNotEmpty) {
        _memory[text] = saved;
        return saved;
      }

      if (!await _prepare()) return null;
      final out = (await _translator!.translateText(text)).trim();
      if (out.isEmpty) return null;
      _memory[text] = out;
      await DatabaseHelper.instance.saveTranslation(text, out);
      return out;
    } catch (_) {
      return null;
    }
  }
}
