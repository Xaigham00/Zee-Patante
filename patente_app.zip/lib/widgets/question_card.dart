import 'package:flutter/material.dart';
import '../data/models.dart';
import '../theme.dart';
import '../widgets_bilingual_text.dart';

/// Question card: label pill, sign image, question text, big VERO / FALSO
/// buttons (+ explanation card in practice mode).
class QuestionCard extends StatelessWidget {
  final Question q;
  final bool? selected;        // user's answer
  final bool reveal;           // show right/wrong + explanation (practice mode)
  final ValueChanged<bool>? onAnswer;
  final String? label;         // e.g. "Domanda 3/30"

  const QuestionCard({
    super.key,
    required this.q,
    this.selected,
    this.reveal = false,
    this.onAnswer,
    this.label,
  });

  Widget _btn(String text, bool value) {
    final isVero = value;
    final color = isVero ? AppColors.green : AppColors.red;
    final edge = isVero ? AppColors.greenDark : AppColors.redDark;

    double opacity = 1;
    IconData? mark;
    if (selected != null) {
      if (reveal) {
        // Practice: highlight the right answer, dim the other one.
        final isRight = value == q.isTrue;
        opacity = isRight ? 1 : 0.35;
        if (isRight) {
          mark = Icons.check_circle;
        } else if (selected == value) {
          mark = Icons.cancel;
        }
      } else {
        // Exam: only show which one was picked.
        opacity = selected == value ? 1 : 0.45;
        if (selected == value) mark = Icons.radio_button_checked;
      }
    }

    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: ChunkyButton(
          color: color,
          edge: edge,
          opacity: opacity,
          onPressed: (reveal && selected != null) || onAnswer == null
              ? null
              : () => onAnswer!(value),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (mark != null) ...[Icon(mark, size: 22), const SizedBox(width: 8)],
            Text(text),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    final answered = reveal && selected != null;
    final correct = selected == q.isTrue;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (label != null) ...[
              Pill(label!),
              const SizedBox(height: 14),
            ],
            if (q.image != null)
              Center(
                child: Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: dark
                            ? const Color(0xFF475569)
                            : const Color(0xFFE2E8F0)),
                  ),
                  child: Image.asset('assets/signs/${q.image}',
                      height: 170,
                      errorBuilder: (_, __, ___) => const SizedBox.shrink()),
                ),
              ),
            BilingualText(q.textIt, q.textUr,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 22),
            Row(children: [_btn('VERO', true), _btn('FALSO', false)]),
            const SizedBox(height: 4),
          ]),
        ),
        if (answered) ...[
          const SizedBox(height: 16),
          AppCard(
            borderColor: correct ? AppColors.green : AppColors.red,
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(correct ? Icons.check_circle : Icons.cancel,
                      color: correct ? AppColors.green : AppColors.red),
                  const SizedBox(width: 8),
                  Text(
                    correct ? 'Corretto / درست' : 'Sbagliato / غلط',
                    style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        color: correct ? AppColors.green : AppColors.red),
                  ),
                ]),
                const SizedBox(height: 10),
                BilingualText(
                  q.explanationIt ?? 'Risposta: ${q.isTrue ? "Vero" : "Falso"}',
                  q.explanationUr ?? 'جواب: ${q.isTrue ? "درست" : "غلط"}',
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
