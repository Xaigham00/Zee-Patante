import 'package:flutter/material.dart';
import '../data/models.dart';
import '../widgets_bilingual_text.dart';

/// Question text + image + Vero/Falso buttons (+ optional explanation).
class QuestionCard extends StatelessWidget {
  final Question q;
  final bool? selected;        // user's answer
  final bool reveal;           // show right/wrong + explanation (practice mode)
  final ValueChanged<bool>? onAnswer;

  const QuestionCard({
    super.key,
    required this.q,
    this.selected,
    this.reveal = false,
    this.onAnswer,
  });

  Color? _color(BuildContext c, bool value) {
    if (selected == null) return null;
    if (!reveal) return selected == value ? Theme.of(c).colorScheme.primaryContainer : null;
    if (value == q.isTrue) return Colors.green.shade600;
    if (selected == value) return Colors.red.shade600;
    return null;
  }

  Widget _btn(BuildContext c, String label, bool value) {
    final col = _color(c, value);
    final onColored = reveal && col != null;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: FilledButton.tonal(
          style: FilledButton.styleFrom(
            backgroundColor: col,
            foregroundColor: onColored ? Colors.white : null,
            padding: const EdgeInsets.symmetric(vertical: 18),
          ),
          onPressed: (reveal && selected != null) || onAnswer == null
              ? null
              : () => onAnswer!(value),
          child: Text(label, style: const TextStyle(fontSize: 18)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (q.image != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Image.asset('assets/signs/${q.image}',
                height: 160,
                errorBuilder: (_, __, ___) => const SizedBox.shrink()),
          ),
        BilingualText(q.textIt, q.textUr,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
        const SizedBox(height: 24),
        Row(children: [_btn(context, 'VERO', true), _btn(context, 'FALSO', false)]),
        if (reveal && selected != null) ...[
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    selected == q.isTrue ? '✓ Corretto / درست' : '✗ Sbagliato / غلط',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: selected == q.isTrue ? Colors.green : Colors.red),
                  ),
                  const SizedBox(height: 8),
                  BilingualText(
                    q.explanationIt ?? 'Risposta: ${q.isTrue ? "Vero" : "Falso"}',
                    q.explanationUr ?? 'جواب: ${q.isTrue ? "درست" : "غلط"}',
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }
}
