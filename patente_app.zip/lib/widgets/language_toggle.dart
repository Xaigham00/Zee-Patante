import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/language_provider.dart';
import '../data/models.dart';

class LanguageToggle extends StatelessWidget {
  const LanguageToggle({super.key});
  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    return PopupMenuButton<LangMode>(
      icon: const Icon(Icons.translate),
      tooltip: 'Language / زبان',
      initialValue: lang.mode,
      onSelected: lang.setMode,
      itemBuilder: (_) => const [
        PopupMenuItem(value: LangMode.italian, child: Text('Italiano')),
        PopupMenuItem(value: LangMode.urdu, child: Text('اردو')),
        PopupMenuItem(value: LangMode.both, child: Text('Italiano + اردو')),
      ],
    );
  }
}
