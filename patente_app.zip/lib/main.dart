import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data/language_provider.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(
    create: (_) => LanguageProvider()..load(),
    child: const PatenteApp(),
  ));
}

class PatenteApp extends StatelessWidget {
  const PatenteApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Patente B',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            colorSchemeSeed: const Color(0xFF1B6B4A), useMaterial3: true),
        darkTheme: ThemeData(
            colorSchemeSeed: const Color(0xFF1B6B4A),
            brightness: Brightness.dark,
            useMaterial3: true),
        home: const HomeScreen(),
      );
}
