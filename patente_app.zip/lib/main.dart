import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data/language_provider.dart';
import 'screens/home_screen.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(
    create: (_) => LanguageProvider()..load(),
    child: const PatenteApp(),
  ));
}

class PatenteApp extends StatelessWidget {
  const PatenteApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Patente B',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const HomeScreen(),
      );
}
