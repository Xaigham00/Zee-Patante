import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'data/language_provider.dart';

/// Shows Italian and/or Urdu depending on the global toggle.
/// Urdu is right-to-left with a Nastaliq font.
class BilingualText extends StatelessWidget {
  final String it;
  final String? ur;
  final TextStyle? style;
  const BilingualText(this.it, this.ur, {super.key, this.style});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    final children = <Widget>[];
    if (lang.showIt) children.add(Text(it, style: style));
    if (lang.showUr && ur != null && ur!.isNotEmpty) {
      children.add(Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          width: double.infinity,
          child: Text(ur!,
              textAlign: TextAlign.right,
              style: GoogleFonts.notoNastaliqUrdu(
                  textStyle: style, height: 2.0)),
        ),
      ));
    }
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }
}
