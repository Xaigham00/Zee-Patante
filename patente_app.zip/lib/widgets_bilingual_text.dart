import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'data/language_provider.dart';
import 'data/translator_service.dart';

/// Shows Italian and/or Urdu depending on the global toggle.
/// If there is no stored Urdu text, it is translated on the device (free).
class BilingualText extends StatelessWidget {
  final String it;
  final String? ur;
  final TextStyle? style;
  const BilingualText(this.it, this.ur, {super.key, this.style});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>();
    final children = <Widget>[];
    if (lang.showIt) children.add(Text(it, style: style));
    if (lang.showUr) children.add(UrduText(it, ur, style: style));
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }
}

/// Urdu line (right-to-left, Nastaliq font). Uses the stored Urdu [ur] when
/// there is one, otherwise translates the Italian [it] on the device.
class UrduText extends StatefulWidget {
  final String it;
  final String? ur;
  final TextStyle? style;
  const UrduText(this.it, this.ur, {super.key, this.style});

  @override
  State<UrduText> createState() => _UrduTextState();
}

class _UrduTextState extends State<UrduText> {
  Future<String?>? _auto;

  @override
  void didUpdateWidget(UrduText old) {
    super.didUpdateWidget(old);
    if (old.it != widget.it || old.ur != widget.ur) _auto = null;
  }

  Widget _rtl(String text, {TextStyle? style}) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          width: double.infinity,
          child: Text(text,
              textAlign: TextAlign.right,
              style: GoogleFonts.notoNastaliqUrdu(
                  textStyle: style ?? widget.style, height: 2.0)),
        ),
      );

  Widget _note(BuildContext context, String text) => _rtl(text,
      style: TextStyle(
          fontSize: 13,
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5)));

  @override
  Widget build(BuildContext context) {
    final stored = widget.ur;
    if (stored != null && stored.isNotEmpty) return _rtl(stored);
    _auto ??= TranslatorService.instance.translate(widget.it);
    return FutureBuilder<String?>(
      future: _auto,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return _note(context, 'ترجمہ ہو رہا ہے…');
        }
        final text = snap.data;
        if (text == null || text.isEmpty) {
          return _note(context,
              'اردو ترجمہ کے لیے پہلی بار انٹرنیٹ سے ڈاؤن لوڈ ضروری ہے');
        }
        return _rtl(text);
      },
    );
  }
}
