import 'dart:async';
import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../data/models.dart';
import '../widgets/language_toggle.dart';
import '../widgets/question_card.dart';
import 'result_screen.dart';

/// Exam simulation: 30 questions, 20 minutes, max 3 errors. No feedback until the end.
class ExamScreen extends StatefulWidget {
  const ExamScreen({super.key});
  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  static const examSeconds = 20 * 60;
  List<Question>? _qs;
  final Map<int, bool?> _answers = {};
  int _i = 0;
  int _left = examSeconds;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    DatabaseHelper.instance.examQuestions().then((qs) {
      if (!mounted) return;
      setState(() {
        _qs = qs;
        for (final q in qs) {
          _answers[q.id] = null;
        }
      });
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (_left <= 1) {
          _finish();
        } else {
          setState(() => _left--);
        }
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _clock {
    final m = (_left ~/ 60).toString().padLeft(2, '0');
    final s = (_left % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _confirmFinish() async {
    final unanswered = _answers.values.where((a) => a == null).length;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Terminare? / ختم کریں؟'),
        content: Text(unanswered == 0
            ? 'Hai risposto a tutte le domande.'
            : '$unanswered domande senza risposta (contano come errori).'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Sì')),
        ],
      ),
    );
    if (ok == true) _finish();
  }

  Future<void> _finish() async {
    _timer?.cancel();
    final qs = _qs!;
    final correctness = <int, bool>{
      for (final q in qs) q.id: _answers[q.id] == q.isTrue
    };
    final errors = correctness.values.where((c) => !c).length;
    final result = ExamResult(errors, examSeconds - _left);
    await DatabaseHelper.instance.saveExam(result, _answers, correctness);
    for (final q in qs) {
      if (_answers[q.id] != null) {
        await DatabaseHelper.instance.saveAnswer(q.id, correctness[q.id]!);
      }
    }
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
          builder: (_) => ResultScreen(result: result, questions: qs, answers: _answers)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final qs = _qs;
    if (qs == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final q = qs[_i];
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmFinish();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('${_i + 1}/${qs.length}'),
          actions: [
            Center(
              child: Text(_clock,
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _left < 120 ? Colors.red : null)),
            ),
            const LanguageToggle(),
          ],
        ),
        body: QuestionCard(
          key: ValueKey(q.id),
          q: q,
          selected: _answers[q.id],
          reveal: false,
          onAnswer: (v) => setState(() => _answers[q.id] = v),
        ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                IconButton(
                    onPressed: _i > 0 ? () => setState(() => _i--) : null,
                    icon: const Icon(Icons.arrow_back)),
                Expanded(
                  child: _i == qs.length - 1
                      ? FilledButton(onPressed: _confirmFinish, child: const Text('Termina / ختم'))
                      : FilledButton.tonal(
                          onPressed: () => setState(() => _i++),
                          child: const Text('Avanti / اگلا')),
                ),
                IconButton(
                    onPressed: _i < qs.length - 1 ? () => setState(() => _i++) : null,
                    icon: const Icon(Icons.arrow_forward)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
