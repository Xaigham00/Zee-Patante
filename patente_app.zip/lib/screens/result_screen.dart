import 'package:flutter/material.dart';
import '../data/models.dart';
import '../widgets/language_toggle.dart';
import '../widgets_bilingual_text.dart';

class ResultScreen extends StatelessWidget {
  final ExamResult result;
  final List<Question> questions;
  final Map<int, bool?> answers;
  const ResultScreen(
      {super.key, required this.result, required this.questions, required this.answers});

  @override
  Widget build(BuildContext context) {
    final wrong = questions.where((q) => answers[q.id] != q.isTrue).toList();
    final passed = result.passed;
    final mins = result.durationSec ~/ 60, secs = result.durationSec % 60;
    return Scaffold(
      appBar: AppBar(title: const Text('Risultato / نتیجہ'), actions: const [LanguageToggle()]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: passed ? Colors.green.shade100 : Colors.red.shade100,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                Text(passed ? 'PROMOSSO / کامیاب' : 'BOCCIATO / ناکام',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: passed ? Colors.green.shade900 : Colors.red.shade900)),
                const SizedBox(height: 8),
                Text('Errori / غلطیاں: ${result.errors} (max 3)',
                    style: const TextStyle(color: Colors.black87)),
                Text('Tempo: $mins:${secs.toString().padLeft(2, '0')}',
                    style: const TextStyle(color: Colors.black87)),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          if (wrong.isNotEmpty)
            const Text('Domande sbagliate / غلط سوالات',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          for (final q in wrong)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  BilingualText(q.textIt, q.textUr,
                      style: const TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(height: 8),
                  Text(
                    'Tua risposta: ${answers[q.id] == null ? "—" : (answers[q.id]! ? "Vero" : "Falso")}'
                    '   |   Corretta: ${q.isTrue ? "Vero" : "Falso"}',
                    style: const TextStyle(color: Colors.red),
                  ),
                  if (q.explanationIt != null) ...[
                    const SizedBox(height: 8),
                    BilingualText(q.explanationIt!, q.explanationUr),
                  ],
                ]),
              ),
            ),
          const SizedBox(height: 12),
          FilledButton(
              onPressed: () => Navigator.pop(context), child: const Text('Home')),
        ],
      ),
    );
  }
}
