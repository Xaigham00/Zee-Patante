import 'package:flutter/material.dart';
import '../data/models.dart';
import '../theme.dart';
import '../widgets/language_toggle.dart';
import '../widgets_bilingual_text.dart';

class ResultScreen extends StatelessWidget {
  final ExamResult result;
  final List<Question> questions;
  final Map<int, bool?> answers;
  const ResultScreen(
      {super.key, required this.result, required this.questions, required this.answers});

  @override
  Widget build(BuildContext context) {
    final wrong = questions.where((q) => answers[q.id] != q.isTrue).toList();
    final passed = result.passed;
    final mins = result.durationSec ~/ 60, secs = result.durationSec % 60;
    final colors = passed
        ? const [AppColors.green, AppColors.greenDark]
        : const [AppColors.red, AppColors.redDark];
    return Scaffold(
      appBar: const GradientAppBar(
          title: Text('Risultato / نتیجہ'), actions: [LanguageToggle()]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                  colors: colors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              boxShadow: [
                BoxShadow(
                    color: colors.first.withOpacity(0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 6)),
              ],
            ),
            child: Column(children: [
              Icon(passed ? Icons.emoji_events : Icons.sentiment_dissatisfied,
                  size: 44, color: Colors.white),
              const SizedBox(height: 8),
              Text(passed ? 'PROMOSSO / کامیاب' : 'BOCCIATO / ناکام',
                  style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: Colors.white)),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(
                    child: _ResultTile(
                        Icons.close, 'Errori / غلطیاں', '${result.errors} (max 3)')),
                const SizedBox(width: 10),
                Expanded(
                    child: _ResultTile(Icons.timer, 'Tempo / وقت',
                        '$mins:${secs.toString().padLeft(2, '0')}')),
              ]),
            ]),
          ),
          const SizedBox(height: 20),
          if (wrong.isNotEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 4),
              child: Text('Domande sbagliate / غلط سوالات',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            ),
          if (wrong.isNotEmpty) const SizedBox(height: 10),
          for (final q in wrong)
            AppCard(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                BilingualText(q.textIt, q.textUr,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 6, children: [
                  Pill(
                      'Tua risposta: ${answers[q.id] == null ? "—" : (answers[q.id]! ? "Vero" : "Falso")}',
                      color: AppColors.red.withOpacity(0.15),
                      textColor: AppColors.red),
                  Pill('Corretta: ${q.isTrue ? "Vero" : "Falso"}',
                      color: AppColors.green.withOpacity(0.15),
                      textColor: AppColors.green),
                ]),
                if (q.explanationIt != null) ...[
                  const SizedBox(height: 10),
                  BilingualText(q.explanationIt!, q.explanationUr),
                ],
              ]),
            ),
          const SizedBox(height: 8),
          ChunkyButton(
            color: AppColors.navy2,
            edge: AppColors.navy,
            onPressed: () => Navigator.pop(context),
            child: const Text('Home'),
          ),
        ],
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const _ResultTile(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.16),
            borderRadius: BorderRadius.circular(14)),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 16, color: Colors.white),
            const SizedBox(width: 4),
            Flexible(
              child: Text(label,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w800)),
            ),
          ]),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900)),
        ]),
      );
}
