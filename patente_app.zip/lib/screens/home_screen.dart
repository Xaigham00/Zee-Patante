import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../data/models.dart';
import '../widgets/language_toggle.dart';
import 'exam_screen.dart';
import 'quiz_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Chapter>> _chapters = DatabaseHelper.instance.chapters();

  void _open(Widget screen) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => screen));

  Future<void> _openChapter(Chapter c) async {
    final qs = await DatabaseHelper.instance.questionsByChapter(c.id);
    qs.shuffle();
    if (!mounted) return;
    _open(QuizScreen(title: c.titleIt, questions: qs));
  }

  Future<void> _openMistakes() async {
    final qs = await DatabaseHelper.instance.mistakes();
    if (!mounted) return;
    if (qs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Nessun errore da ripassare / کوئی غلطی نہیں')));
      return;
    }
    _open(QuizScreen(title: 'Ripasso errori', questions: qs));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Patente B'), actions: const [LanguageToggle()]),
      body: FutureBuilder<List<Chapter>>(
        future: _chapters,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final chapters = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              FilledButton.icon(
                icon: const Icon(Icons.timer),
                label: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Simulazione esame / امتحان کی مشق'),
                ),
                onPressed: () => _open(const ExamScreen()),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.replay),
                label: const Text('Ripasso errori / غلطیاں دہرائیں'),
                onPressed: _openMistakes,
              ),
              const SizedBox(height: 20),
              const Text('Argomenti / موضوعات',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              for (final c in chapters)
                Card(
                  child: ListTile(
                    title: Text(c.titleIt),
                    subtitle: c.titleUr == null ? null : Text(c.titleUr!),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _openChapter(c),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
