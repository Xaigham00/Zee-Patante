import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../data/models.dart';
import '../theme.dart';
import '../widgets/language_toggle.dart';
import 'exam_screen.dart';
import 'quiz_screen.dart';

typedef _HomeData = ({
  List<Chapter> chapters,
  Map<int, Stats> stats,
  Map<int, List<String>> images,
});

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<_HomeData> _data = _load();

  Future<_HomeData> _load() async {
    final db = DatabaseHelper.instance;
    final chapters = await db.chapters();
    final stats = await db.chapterStats();
    final images = await db.chapterImages();
    return (chapters: chapters, stats: stats, images: images);
  }

  /// Opens a screen and refreshes the progress numbers when coming back.
  Future<void> _open(Widget screen) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
    if (mounted) setState(() => _data = _load());
  }

  Future<void> _openChapter(Chapter c) async {
    final qs = await DatabaseHelper.instance.questionsByChapter(c.id);
    qs.shuffle();
    if (!mounted) return;
    _open(QuizScreen(title: c.titleIt, questions: qs));
  }

  Future<void> _openMistakes() async {
    final qs = await DatabaseHelper.instance.mistakes();
    if (!mounted) return;
    if (qs.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Nessun errore da ripassare / کوئی غلطی نہیں')));
      return;
    }
    _open(QuizScreen(title: 'Ripasso errori', questions: qs));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const GradientAppBar(
        title: Row(children: [
          Icon(Icons.directions_car_filled, size: 24),
          SizedBox(width: 10),
          Text('Patente B'),
        ]),
        actions: [LanguageToggle()],
      ),
      body: FutureBuilder<_HomeData>(
        future: _data,
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final d = snap.data!;
          final all = Stats.sum(d.stats.values);
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              _SummaryCard(all),
              const SizedBox(height: 20),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text('Argomenti / موضوعات',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 10),
              for (var i = 0; i < d.chapters.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _ChapterCard(
                    index: i,
                    chapter: d.chapters[i],
                    stats: d.stats[d.chapters[i].id] ?? const Stats(0, 0, 0),
                    images: d.images[d.chapters[i].id] ?? const [],
                    onTap: () => _openChapter(d.chapters[i]),
                  ),
                ),
            ],
          );
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (i) {
          if (i == 1) _open(const ExamScreen());
          if (i == 2) _openMistakes();
        },
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.menu_book_outlined),
              selectedIcon: Icon(Icons.menu_book),
              label: 'Argomenti'),
          NavigationDestination(
              icon: Icon(Icons.timer_outlined),
              selectedIcon: Icon(Icons.timer),
              label: 'Esame'),
          NavigationDestination(
              icon: Icon(Icons.replay), label: 'Errori'),
        ],
      ),
    );
  }
}

/// Green "whole course" card with overall progress.
class _SummaryCard extends StatelessWidget {
  final Stats s;
  const _SummaryCard(this.s);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
            colors: [AppColors.green, AppColors.greenDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
        boxShadow: [
          BoxShadow(
              color: AppColors.green.withOpacity(0.35),
              blurRadius: 14,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Icon(Icons.school, color: Colors.white),
          SizedBox(width: 8),
          Text('Tutto il corso / پورا کورس',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 4),
        Text('${(s.done * 100).round()}% completato',
            style: const TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        StatRow(
            correct: s.correct,
            wrong: s.wrong,
            todo: s.todo,
            total: s.total,
            onDark: true),
        const SizedBox(height: 12),
        SoftProgress(s.done, onDark: true),
      ]),
    );
  }
}

const _bannerGradients = <List<Color>>[
  [Color(0xFF1E2A5E), Color(0xFF3B5BDB)],
  [Color(0xFF0B4F4A), Color(0xFF1AA39A)],
  [Color(0xFF4A1D6B), Color(0xFF9B4DCA)],
  [Color(0xFF7A2E0E), Color(0xFFE8590C)],
  [Color(0xFF14532D), Color(0xFF40A860)],
  [Color(0xFF7F1D1D), Color(0xFFD64545)],
];

class _ChapterCard extends StatelessWidget {
  final int index;
  final Chapter chapter;
  final Stats stats;
  final List<String> images;
  final VoidCallback onTap;
  const _ChapterCard({
    required this.index,
    required this.chapter,
    required this.stats,
    required this.images,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final g = _bannerGradients[index % _bannerGradients.length];
    return AppCard(
      padding: EdgeInsets.zero,
      onTap: onTap,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Banner: gradient + big faded number + the chapter's real sign images.
        Container(
          height: 120,
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: g,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight),
          ),
          child: Stack(children: [
            Positioned(
              right: 14,
              top: -6,
              child: Text('${index + 1}',
                  style: TextStyle(
                      fontSize: 96,
                      height: 1,
                      fontWeight: FontWeight.w900,
                      color: Colors.white.withOpacity(0.14))),
            ),
            Center(
              child: images.isEmpty
                  ? const Icon(Icons.menu_book,
                      size: 54, color: Colors.white70)
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        for (final img in images)
                          Container(
                            width: 70,
                            height: 70,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 6,
                                    offset: Offset(0, 3))
                              ],
                            ),
                            child: Image.asset('assets/signs/$img',
                                fit: BoxFit.contain,
                                cacheWidth: 160,
                                errorBuilder: (_, __, ___) =>
                                    const SizedBox.shrink()),
                          ),
                      ],
                    ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${index + 1}) ${chapter.titleIt}',
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            if (chapter.titleUr != null)
              SizedBox(
                width: double.infinity,
                child: Text(chapter.titleUr!,
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(
                        color: AppColors.green,
                        fontSize: 15,
                        fontWeight: FontWeight.w700)),
              ),
            const SizedBox(height: 4),
            Text('${stats.total} domande',
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6))),
            const SizedBox(height: 10),
            StatRow(
                correct: stats.correct,
                wrong: stats.wrong,
                todo: stats.todo,
                total: stats.total),
            const SizedBox(height: 10),
            SoftProgress(stats.done),
          ]),
        ),
      ]),
    );
  }
}
