import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../data/models.dart';
import '../theme.dart';
import '../widgets/language_toggle.dart';
import '../widgets/question_card.dart';

/// Practice mode: instant feedback + explanation after every answer.
class QuizScreen extends StatefulWidget {
  final String title;
  final List<Question> questions;
  const QuizScreen({super.key, required this.title, required this.questions});
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _i = 0, _correct = 0;
  bool? _selected;

  Question get q => widget.questions[_i];

  Future<void> _answer(bool v) async {
    setState(() {
      _selected = v;
      if (v == q.isTrue) _correct++;
    });
    await DatabaseHelper.instance.saveAnswer(q.id, v == q.isTrue);
  }

  void _next() {
    if (_i + 1 >= widget.questions.length) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Fine / ختم'),
          content: Text('$_correct / ${widget.questions.length}'),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: const Text('OK'))
          ],
        ),
      );
      return;
    }
    setState(() {
      _i++;
      _selected = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.questions.length;
    return Scaffold(
      appBar: GradientAppBar(
        title: Text(widget.title, overflow: TextOverflow.ellipsis),
        actions: [
          Center(
              child: Pill('${_i + 1}/$total',
                  color: Colors.white24, textColor: Colors.white)),
          IconButton(
            icon: const Icon(Icons.bookmark_border),
            onPressed: () => DatabaseHelper.instance.toggleBookmark(q.id),
          ),
          const LanguageToggle(),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(6),
          child: LinearProgressIndicator(
            value: (_i + 1) / total,
            minHeight: 6,
            backgroundColor: Colors.white24,
            valueColor: const AlwaysStoppedAnimation(Color(0xFF6EE7A0)),
          ),
        ),
      ),
      body: QuestionCard(
        key: ValueKey(q.id),
        q: q,
        label: 'Domanda ${_i + 1}/$total · سوال',
        selected: _selected,
        reveal: true,
        onAnswer: _answer,
      ),
      bottomNavigationBar: _selected == null
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: ChunkyButton(
                  color: AppColors.green,
                  edge: AppColors.greenDark,
                  onPressed: _next,
                  child: Text(_i + 1 >= total ? 'Termina' : 'Avanti / اگلا'),
                ),
              ),
            ),
    );
  }
}
