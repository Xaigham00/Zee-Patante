CREATE TABLE chapters (
  id INTEGER PRIMARY KEY,
  title_it TEXT NOT NULL,
  title_ur TEXT,
  sort_order INTEGER NOT NULL
);

CREATE TABLE lessons (
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL REFERENCES chapters(id),
  title_it TEXT NOT NULL,
  title_ur TEXT,
  body_it TEXT NOT NULL,
  body_ur TEXT,
  sort_order INTEGER NOT NULL
);

CREATE TABLE questions (
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL REFERENCES chapters(id),
  text_it TEXT NOT NULL,
  text_ur TEXT,
  is_true INTEGER NOT NULL,          -- 1 = Vero, 0 = Falso
  image TEXT,                        -- e.g. signs/42.png
  explanation_it TEXT,
  explanation_ur TEXT
);
CREATE INDEX idx_q_chapter ON questions(chapter_id);

-- User data
CREATE TABLE progress (
  question_id INTEGER PRIMARY KEY REFERENCES questions(id),
  attempts INTEGER NOT NULL DEFAULT 0,
  correct_count INTEGER NOT NULL DEFAULT 0,
  last_correct INTEGER,
  last_at INTEGER
);

CREATE TABLE bookmarks (
  question_id INTEGER PRIMARY KEY REFERENCES questions(id)
);

CREATE TABLE exams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  taken_at INTEGER NOT NULL,
  total INTEGER NOT NULL DEFAULT 30,
  errors INTEGER NOT NULL,
  passed INTEGER NOT NULL,           -- errors <= 3
  duration_sec INTEGER NOT NULL
);

CREATE TABLE exam_answers (
  exam_id INTEGER NOT NULL REFERENCES exams(id),
  question_id INTEGER NOT NULL REFERENCES questions(id),
  answer INTEGER,                    -- null = unanswered
  correct INTEGER NOT NULL,
  PRIMARY KEY (exam_id, question_id)
);
