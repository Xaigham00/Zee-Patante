import { useState } from "react";
import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { BookOpen, Check, CheckSquare, ChevronDown, Layers, PencilLine, X } from "lucide-react";
import { chapterTopicsQuery, chaptersQuery, signUrl, type Topic } from "@/lib/content";
import { done, topicStats, useProgress } from "@/lib/progress";
import { useLang } from "@/lib/language";
import { cn } from "@/lib/utils";
import { AppBar } from "@/components/patente/AppBar";
import { AppCard, chunkyClass, SoftProgress, StatRow } from "@/components/patente/ui";

export const Route = createFileRoute("/capitolo/$chapterId")({
  loader: async ({ context, params }) => {
    const id = Number(params.chapterId);
    if (!Number.isInteger(id)) throw notFound();
    const data = await context.queryClient.ensureQueryData(chapterTopicsQuery(id));
    if (!data.chapter) throw notFound();
    return { title: data.chapter.title_it, count: data.topics.length };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.title ?? "Argomento"} — Quiz Patente B` },
      {
        name: "description",
        content: `${loaderData?.count ?? ""} argomenti del capitolo "${loaderData?.title ?? ""}", ognuno con il suo quiz Vero/Falso.`,
      },
      { property: "og:title", content: `${loaderData?.title ?? "Argomento"} — Quiz Patente B` },
      { property: "og:description", content: "Scegli un argomento ed esercitati con le sue domande." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChapterTopics,
});

function ChapterTopics() {
  const { chapterId } = Route.useParams();
  const id = Number(chapterId);
  const { data } = useSuspenseQuery(chapterTopicsQuery(id));
  const { data: chapters } = useQuery(chaptersQuery);
  const navigate = useNavigate();
  const [selected, setSelected] = useState<number[]>([]);
  const [prevId, setPrevId] = useState(id);
  if (prevId !== id) {
    setPrevId(id);
    setSelected([]);
  }

  const { chapter, topics } = data;
  const capNo = chapter?.sort_order ?? id;
  const toggle = (tid: number) =>
    setSelected((s) => (s.includes(tid) ? s.filter((x) => x !== tid) : [...s, tid]));
  const selTopics = topics.filter((t) => selected.includes(t.id));
  const selCount = selTopics.reduce((a, t) => a + t.question_count, 0);

  return (
    <div className={cn("min-h-screen", selected.length ? "pb-32" : "pb-10")}>
      <AppBar back title={`Cap ${capNo} · ${chapter?.title_it ?? ""}`} />
      <main className="mx-auto max-w-2xl space-y-4 p-4">
        <AppCard className="space-y-3 p-3">
          <div className="relative">
            <select
              aria-label="Capitolo"
              value={id}
              onChange={(e) =>
                navigate({ to: "/capitolo/$chapterId", params: { chapterId: e.target.value } })
              }
              className="w-full appearance-none rounded-2xl border-2 bg-card py-3.5 pr-10 pl-4 text-lg font-extrabold text-foreground focus:border-vero focus:outline-none"
            >
              {(chapters ?? [{ id, title_it: chapter?.title_it ?? "", sort_order: capNo }]).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.sort_order}) {c.title_it}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute top-1/2 right-4 size-5 -translate-y-1/2 text-muted-foreground" />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <ToolButton onClick={() => setSelected(topics.map((t) => t.id))} icon={<CheckSquare className="size-4 shrink-0 text-vero" />}>
              Tutti
            </ToolButton>
            <ToolButton onClick={() => setSelected([])} icon={<X className="size-4 shrink-0 text-falso" />}>
              Nessuno
            </ToolButton>
            <Link
              to="/"
              className="flex items-center justify-center gap-1.5 rounded-xl bg-tile px-2 py-3 text-sm font-extrabold shadow-card"
            >
              <Layers className="size-4 shrink-0 text-navy-2" /> Capitoli
            </Link>
          </div>
        </AppCard>

        {topics.map((t, i) => (
          <TopicCard
            key={t.id}
            index={i}
            topic={t}
            checked={selected.includes(t.id)}
            onToggle={() => toggle(t.id)}
          />
        ))}
      </main>

      {selected.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-20 bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur">
          <div className="mx-auto max-w-2xl px-4 pt-2 pb-5">
            <Link
              to="/quiz"
              search={{ t: selTopics.map((t) => t.id).join(",") }}
              className={chunkyClass("vero", "text-lg")}
            >
              <PencilLine className="size-5" />
              Quiz · {selected.length} argomenti · {selCount} domande
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

function ToolButton({
  children,
  icon,
  onClick,
}: {
  children: React.ReactNode;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center justify-center gap-1.5 rounded-xl bg-tile px-2 py-3 text-sm font-extrabold shadow-card active:scale-[0.98]"
    >
      {icon}
      {children}
    </button>
  );
}

function TopicCard({
  index,
  topic,
  checked,
  onToggle,
}: {
  index: number;
  topic: Topic;
  checked: boolean;
  onToggle: () => void;
}) {
  const progress = useProgress();
  const { showIt, showUr } = useLang();
  const stats = topicStats(progress, topic.id, topic.question_count);
  const img = signUrl(topic.image);
  const title = topic.title_it ?? `Quesito ${index + 1}`;
  const checkboxId = `topic-${topic.id}`;

  return (
    <AppCard className={cn("space-y-3 p-4 transition-shadow", checked && "ring-2 ring-vero")}>
      <div className="flex items-start gap-3">
        <button
          type="button"
          id={checkboxId}
          role="checkbox"
          aria-checked={checked}
          aria-label={`Seleziona ${title}`}
          onClick={onToggle}
          className={cn(
            "mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg border-2 transition-colors",
            checked ? "border-vero bg-vero text-on-brand" : "border-muted-foreground/40 bg-card",
          )}
        >
          {checked && <Check className="size-4" strokeWidth={3} />}
        </button>
        <label htmlFor={checkboxId} className="min-w-0 flex-1 cursor-pointer">
          {(showIt || !topic.title_ur) && (
            <h3 className="text-[17px] leading-snug font-black">
              {index + 1}) {title}
            </h3>
          )}
          {showUr && topic.title_ur && (
            <p lang="ur" className={cn("urdu text-[15px] font-bold text-vero", !showIt && "text-lg")}>
              {!showIt && `${index + 1}) `}
              {topic.title_ur}
            </p>
          )}
        </label>
      </div>

      {img && (
        <Link to="/quiz" search={{ t: String(topic.id) }} className="flex justify-center">
          <div className="rounded-2xl border bg-sign-plate p-3">
            <img src={img} alt="" loading="lazy" className="h-36 w-auto object-contain" />
          </div>
        </Link>
      )}

      <StatRow stats={stats} />
      <SoftProgress value={done(stats)} />

      <div className="grid grid-cols-2 gap-2.5 pt-1">
        <div className="flex items-center justify-center gap-1.5 rounded-xl bg-tile text-sm font-extrabold text-muted-foreground">
          <BookOpen className="size-4" /> {topic.question_count} domande
        </div>
        <Link
          to="/quiz"
          search={{ t: String(topic.id) }}
          className={chunkyClass("vero", "py-3 text-lg")}
        >
          <PencilLine className="size-5" /> Quiz
        </Link>
      </div>
    </AppCard>
  );
}
