import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { BookOpen, Car, GraduationCap } from "lucide-react";
import { chaptersQuery, signUrl, type ChapterOverview } from "@/lib/content";
import { chapterStats, done, sumStats, useProgress, type Stats } from "@/lib/progress";
import { useLang } from "@/lib/language";
import { cn } from "@/lib/utils";
import { AppBar } from "@/components/patente/AppBar";
import { BottomNav } from "@/components/patente/BottomNav";
import { AppCard, Label2, SoftProgress, StatRow } from "@/components/patente/ui";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Patente B — Quiz in italiano e urdu" },
      {
        name: "description",
        content:
          "Preparati all'esame teorico della patente B: 7.000+ quiz Vero/Falso divisi per argomento, simulazione d'esame e ripasso errori, con supporto urdu.",
      },
      { property: "og:title", content: "Patente B — Quiz in italiano e urdu" },
      {
        property: "og:description",
        content: "Quiz per argomento, simulazione d'esame (30 domande, 20 minuti) e ripasso errori.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(chaptersQuery),
  component: Home,
});

function Home() {
  const { data: chapters } = useSuspenseQuery(chaptersQuery);
  const progress = useProgress();
  const stats = chapters.map((c) => chapterStats(progress, c.id, c.question_count));
  const all = sumStats(stats);

  return (
    <div className="min-h-screen pb-28">
      <AppBar
        title={
          <span className="flex items-center gap-2.5">
            <Car className="size-6" /> Patente B
          </span>
        }
      />
      <main className="mx-auto max-w-2xl space-y-5 px-4 pt-4">
        <SummaryCard s={all} />
        <h2 className="px-1 text-lg font-black">
          <Label2 it="Argomenti" ur="موضوعات" />
        </h2>
        <div className="space-y-4">
          {chapters.map((c, i) => (
            <ChapterCard
              key={c.id}
              index={i}
              chapter={c}
              stats={stats[i] ?? { total: c.question_count, correct: 0, wrong: 0 }}
            />
          ))}
        </div>
      </main>
      <BottomNav active="/" />
    </div>
  );
}

function SummaryCard({ s }: { s: Stats }) {
  return (
    <section className="rounded-[20px] bg-course p-4 text-on-brand">
      <div className="flex items-center gap-2 text-xl font-black">
        <GraduationCap className="size-6" />
        <Label2 it="Tutto il corso" ur="پورا کورس" />
      </div>
      <p className="mt-1 text-[13px] font-bold opacity-75">{Math.round(done(s) * 100)}% completato</p>
      <div className="mt-3">
        <StatRow stats={s} onDark />
      </div>
      <div className="mt-3">
        <SoftProgress value={done(s)} onDark />
      </div>
    </section>
  );
}

const banners = ["banner-1", "banner-2", "banner-3", "banner-4", "banner-5", "banner-6"];

function ChapterCard({ index, chapter, stats }: { index: number; chapter: ChapterOverview; stats: Stats }) {
  const { showUr } = useLang();
  const imgs = chapter.images.map(signUrl).filter((u): u is string => !!u);
  return (
    <Link
      to="/capitolo/$chapterId"
      params={{ chapterId: String(chapter.id) }}
      className="block transition-transform active:scale-[0.99]"
    >
      <AppCard className="overflow-hidden">
        <div className={cn("relative flex h-[120px] items-center justify-center", banners[index % banners.length])}>
          <span className="pointer-events-none absolute -top-1.5 right-3.5 text-8xl leading-none font-black text-on-brand/15">
            {index + 1}
          </span>
          {imgs.length === 0 ? (
            <BookOpen className="size-14 text-on-brand/70" />
          ) : (
            <div className="relative flex gap-2.5">
              {imgs.map((u) => (
                <div key={u} className="grid size-[70px] place-items-center rounded-[14px] bg-sign-plate p-1.5 shadow-sign">
                  <img src={u} alt="" loading="lazy" className="max-h-full max-w-full object-contain" />
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="space-y-2.5 p-3.5">
          <div>
            <h3 className="text-[17px] font-black leading-snug">
              {index + 1}) {chapter.title_it}
            </h3>
            {showUr && chapter.title_ur && (
              <p dir="rtl" className="urdu text-[15px] font-bold text-vero">
                {chapter.title_ur}
              </p>
            )}
            <p className="mt-1 text-[13px] font-bold text-muted-foreground">
              {chapter.topic_count} argomenti · {chapter.question_count} domande
            </p>
          </div>
          <StatRow stats={stats} />
          <SoftProgress value={done(stats)} />
        </div>
      </AppCard>
    </Link>
  );
}
