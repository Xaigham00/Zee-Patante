import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ClipboardCheck, RotateCcw, Trophy } from "lucide-react";
import { topicQuestionsQuery, type TopicQuestions } from "@/lib/content";
import { saveAnswer } from "@/lib/progress";
import { useLang } from "@/lib/language";
import { AppBar } from "@/components/patente/AppBar";
import { LoadingScreen } from "@/components/patente/LoadingScreen";
import { QuestionCard } from "@/components/patente/QuestionCard";
import { AppCard, ChunkyButton, chunkyClass, Pill } from "@/components/patente/ui";

function parseIds(t: string): number[] {
  return [...new Set(t.split(",").map((x) => Number(x.trim())))].filter((n) => Number.isInteger(n) && n > 0);
}

export const Route = createFileRoute("/quiz")({
  validateSearch: (s: Record<string, unknown>): { t: string } => {
    const t = s["t"];
    return { t: typeof t === "string" || typeof t === "number" ? String(t) : "" };
  },
  // Answers are saved in this browser, so the quiz renders on the client.
  ssr: false,
  loaderDeps: ({ search }) => ({ ids: parseIds(search.t) }),
  loader: ({ context, deps }) => context.queryClient.ensureQueryData(topicQuestionsQuery(deps.ids)),
  head: () => ({
    meta: [
      { title: "Quiz per argomento — Patente B" },
      {
        name: "description",
        content: "Rispondi a tutte le domande Vero/Falso dell'argomento, poi controlla i risultati.",
      },
      { property: "og:title", content: "Quiz per argomento — Patente B" },
      { property: "og:description", content: "Esercitati argomento per argomento." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  pendingComponent: LoadingScreen,
  component: TopicQuiz,
});

function TopicQuiz() {
  const { t } = Route.useSearch();
  const ids = parseIds(t);
  const { data } = useSuspenseQuery(topicQuestionsQuery(ids));
  const [round, setRound] = useState(0);
  return <QuestionList key={`${t}-${round}`} data={data} onRestart={() => setRound((r) => r + 1)} />;
}

function QuestionList({
  data,
  onRestart,
}: {
  data: TopicQuestions;
  onRestart: () => void;
}) {
  const navigate = useNavigate();
  const { showIt } = useLang();
  const { questions, topics } = data;
  const [answers, setAnswers] = useState<Record<number, boolean>>({});
  const [checked, setChecked] = useState(false);

  const chapterId = questions[0]?.chapter_id;
  const single = topics.length === 1 ? topics[0] : null;
  const title = single
    ? `L${single.sort_order} — ${showIt || !single.title_ur ? (single.title_it ?? "") : single.title_ur}`
    : `${topics.length} argomenti`;
  const total = questions.length;
  const answered = Object.keys(answers).length;
  const correct = questions.filter((q) => answers[q.id] === q.is_true).length;
  const wrong = questions.filter((q) => q.id in answers && answers[q.id] !== q.is_true).length;

  const back = () =>
    chapterId
      ? navigate({ to: "/capitolo/$chapterId", params: { chapterId: String(chapterId) } })
      : navigate({ to: "/" });

  const showResults = () => {
    if (answered < total && !window.confirm(`${total - answered} domande senza risposta. Mostrare i risultati?`)) return;
    for (const q of questions) {
      const v = answers[q.id];
      if (v !== undefined) saveAnswer(q, v === q.is_true);
    }
    setChecked(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (total === 0) {
    return (
      <div className="min-h-screen">
        <AppBar back title="Quiz" />
        <main className="mx-auto max-w-2xl p-4">
          <AppCard className="p-6 text-center font-bold text-muted-foreground">Nessuna domanda trovata.</AppCard>
        </main>
      </div>
    );
  }

  const actions = (
    <div className="space-y-3 pt-1">
      <ChunkyButton
        onClick={() => {
          window.scrollTo({ top: 0 });
          onRestart();
        }}
      >
        <RotateCcw className="size-5" /> Rifai
      </ChunkyButton>
      {chapterId ? (
        <Link to="/capitolo/$chapterId" params={{ chapterId: String(chapterId) }} className={chunkyClass("navy")}>
          Argomenti
        </Link>
      ) : (
        <Link to="/" className={chunkyClass("navy")}>
          Home
        </Link>
      )}
    </div>
  );

  return (
    <div className="min-h-screen pb-28">
      <AppBar back onBack={back} title={title} progress={answered / total} />
      <main className="mx-auto max-w-2xl space-y-5 p-4">
        {checked && (
          <AppCard className="space-y-4 p-5 text-center animate-pop-in">
            <Trophy className="mx-auto size-10 text-vero" />
            <p className="text-3xl font-black">
              {correct} / {total}
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <Pill className="text-vero">Giuste {correct}</Pill>
              <Pill className="text-falso">Sbagliate {wrong}</Pill>
              {answered < total && <Pill>Senza risposta {total - answered}</Pill>}
            </div>
            {actions}
          </AppCard>
        )}

        {questions.map((q, n) => (
          <QuestionCard
            key={q.id}
            q={q}
            label={`Domanda ${n + 1}/${total} · سوال`}
            selected={answers[q.id] ?? null}
            reveal={checked}
            onAnswer={(v) => {
              if (!checked) setAnswers((a) => ({ ...a, [q.id]: v }));
            }}
          />
        ))}

        {checked && <AppCard className="p-5">{actions}</AppCard>}
      </main>

      {!checked && (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t bg-background/95 p-3 backdrop-blur">
          <div className="mx-auto max-w-2xl">
            <ChunkyButton tone="vero" onClick={showResults}>
              <ClipboardCheck className="size-5" /> Mostra risultati · {answered}/{total}
            </ChunkyButton>
          </div>
        </div>
      )}
    </div>
  );
}
