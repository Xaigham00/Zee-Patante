import { useMemo } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PartyPopper } from "lucide-react";
import { fetchQuestionsByIds, shuffle } from "@/lib/content";
import { mistakeIds, readProgress } from "@/lib/progress";
import { PracticeQuiz } from "@/components/patente/PracticeQuiz";
import { LoadingScreen } from "@/components/patente/LoadingScreen";
import { AppBar } from "@/components/patente/AppBar";
import { BottomNav } from "@/components/patente/BottomNav";
import { AppCard, chunkyClass } from "@/components/patente/ui";

export const Route = createFileRoute("/errori")({
  // Mistakes are stored in this browser, so this page renders on the client.
  ssr: false,
  loader: async () => {
    const ids = mistakeIds(readProgress());
    const questions = ids.length ? await fetchQuestionsByIds(ids) : [];
    return { questions, token: Date.now() };
  },
  head: () => ({
    meta: [
      { title: "Ripasso errori — Patente B" },
      { name: "description", content: "Ripassa le domande del quiz patente B a cui hai risposto in modo sbagliato." },
      { property: "og:title", content: "Ripasso errori — Patente B" },
      { property: "og:description", content: "Rifai solo le domande sbagliate finché non le sai tutte." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  pendingComponent: LoadingScreen,
  component: Mistakes,
});

function Mistakes() {
  const { questions, token } = Route.useLoaderData();
  const list = useMemo(() => shuffle(questions), [questions]);

  if (list.length === 0) {
    return (
      <div className="min-h-screen pb-28">
        <AppBar title="Ripasso errori" />
        <main className="mx-auto max-w-2xl p-4">
          <AppCard className="space-y-4 p-6 text-center">
            <PartyPopper className="mx-auto size-12 text-vero" />
            <p className="text-lg font-black">
              Nessun errore da ripassare / <span className="font-urdu">کوئی غلطی نہیں</span>
            </p>
            <p className="text-sm font-semibold text-muted-foreground">
              Le domande sbagliate nei quiz e negli esami appariranno qui.
            </p>
            <Link to="/" className={chunkyClass("navy")}>
              Argomenti
            </Link>
          </AppCard>
        </main>
        <BottomNav active="/errori" />
      </div>
    );
  }

  return <PracticeQuiz key={token} title="Ripasso errori" questions={list} />;
}
