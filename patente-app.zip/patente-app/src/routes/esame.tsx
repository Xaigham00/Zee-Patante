import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Clock, Frown, Timer, Trophy, X } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { fetchExamQuestions, type Question } from "@/lib/content";
import {
  countErrors,
  EXAM_MAX_ERRORS,
  EXAM_QUESTION_COUNT,
  EXAM_SECONDS,
  formatClock,
  isPassed,
  type Answer,
} from "@/lib/exam";
import { saveExam } from "@/lib/progress";
import { cn } from "@/lib/utils";
import { AppBar } from "@/components/patente/AppBar";
import { QuestionCard } from "@/components/patente/QuestionCard";
import { LoadingScreen } from "@/components/patente/LoadingScreen";
import { AppCard, BilingualText, ChunkyButton, chunkyClass, Label2, Pill } from "@/components/patente/ui";

export const Route = createFileRoute("/esame")({
  // Each visit draws a new random set of questions.
  ssr: false,
  loader: async () => ({
    questions: await fetchExamQuestions(EXAM_QUESTION_COUNT),
    token: Date.now(),
  }),
  head: () => ({
    meta: [
      { title: "Simulazione esame — Patente B" },
      {
        name: "description",
        content: "Simulazione dell'esame teorico patente B: 30 domande, 20 minuti, massimo 3 errori.",
      },
      { property: "og:title", content: "Simulazione esame — Patente B" },
      { property: "og:description", content: "30 domande, 20 minuti, massimo 3 errori. Ce la fai?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  pendingComponent: LoadingScreen,
  component: ExamPage,
});

type Result = { errors: number; durationSec: number; answers: Record<number, Answer> };

function ExamPage() {
  const { questions, token } = Route.useLoaderData();
  const router = useRouter();
  const [result, setResult] = useState<Result | null>(null);

  useEffect(() => setResult(null), [token]);

  if (result) {
    return (
      <ResultView
        result={result}
        questions={questions}
        onRetry={() => {
          setResult(null);
          router.invalidate();
        }}
      />
    );
  }
  return <ExamRunner key={token} questions={questions} onDone={setResult} />;
}

function ExamRunner({ questions, onDone }: { questions: Question[]; onDone: (r: Result) => void }) {
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Record<number, Answer>>(() =>
    Object.fromEntries(questions.map((q) => [q.id, null])),
  );
  const [left, setLeft] = useState(EXAM_SECONDS);
  const [confirm, setConfirm] = useState(false);
  const finishedRef = useRef(false);
  const answersRef = useRef(answers);
  answersRef.current = answers;
  const leftRef = useRef(left);
  leftRef.current = left;

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    const a = answersRef.current;
    const errors = countErrors(questions, a);
    const durationSec = EXAM_SECONDS - leftRef.current;
    saveExam(
      {
        takenAt: Date.now(),
        total: questions.length,
        errors,
        passed: isPassed(errors),
        durationSec,
        answers: questions.map((q) => ({
          questionId: q.id,
          answer: a[q.id] ?? null,
          correct: a[q.id] === q.is_true,
        })),
      },
      questions,
    );
    onDone({ errors, durationSec, answers: a });
  }, [questions, onDone]);

  useEffect(() => {
    const t = window.setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(t);
  }, []);

  // Time's up: the exam ends automatically.
  useEffect(() => {
    if (left === 0) finish();
  }, [left, finish]);

  const total = questions.length;
  const q = questions[Math.min(i, total - 1)] as Question;
  const last = i === total - 1;
  const unanswered = Object.values(answers).filter((a) => a === null).length;

  const go = (n: number) => {
    setI(n);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="min-h-screen pb-32">
      <AppBar
        back
        onBack={() => setConfirm(true)}
        title={`Esame ${i + 1}/${total}`}
        progress={(i + 1) / total}
        actions={
          <Pill
            icon={<Timer className="size-4" />}
            className={cn("tabular-nums text-on-brand", left < 120 ? "bg-falso" : "bg-on-brand/15")}
          >
            {formatClock(left)}
          </Pill>
        }
      />
      <main className="mx-auto max-w-2xl p-4">
        <QuestionCard
          key={q.id}
          q={q}
          label={`Domanda ${i + 1}/${total} · سوال`}
          selected={answers[q.id] ?? null}
          reveal={false}
          onAnswer={(v) => setAnswers((a) => ({ ...a, [q.id]: v }))}
        />
        <div className="mt-4 flex flex-wrap justify-center gap-1.5" aria-label="Domande">
          {questions.map((x, n) => (
            <button
              key={x.id}
              type="button"
              onClick={() => go(n)}
              aria-label={`Domanda ${n + 1}`}
              className={cn(
                "size-8 rounded-lg text-xs font-black transition-colors",
                n === i
                  ? "bg-navy-2 text-on-brand"
                  : answers[x.id] !== null
                    ? "bg-vero/15 text-vero"
                    : "bg-card text-muted-foreground shadow-card",
              )}
            >
              {n + 1}
            </button>
          ))}
        </div>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-20 bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center gap-3 px-4 pt-2 pb-5">
          <button
            type="button"
            aria-label="Precedente"
            disabled={i === 0}
            onClick={() => go(i - 1)}
            className="grid size-12 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground disabled:opacity-40"
          >
            <ArrowLeft className="size-5" />
          </button>
          {last ? (
            <ChunkyButton tone="navy" onClick={() => setConfirm(true)}>
              Termina / <span className="font-urdu">ختم</span>
            </ChunkyButton>
          ) : (
            <ChunkyButton onClick={() => go(i + 1)}>
              Avanti / <span className="font-urdu">اگلا</span>
            </ChunkyButton>
          )}
          <button
            type="button"
            aria-label="Successiva"
            disabled={last}
            onClick={() => go(i + 1)}
            className="grid size-12 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground disabled:opacity-40"
          >
            <ArrowRight className="size-5" />
          </button>
        </div>
      </div>

      <AlertDialog open={confirm} onOpenChange={setConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Terminare? / <span className="font-urdu">ختم کریں؟</span>
            </AlertDialogTitle>
            <AlertDialogDescription>
              {unanswered === 0
                ? "Hai risposto a tutte le domande."
                : `${unanswered} domande senza risposta (contano come errori).`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No</AlertDialogCancel>
            <AlertDialogAction onClick={finish}>Sì</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ResultView({
  result,
  questions,
  onRetry,
}: {
  result: Result;
  questions: Question[];
  onRetry: () => void;
}) {
  const passed = isPassed(result.errors);
  const wrong = questions.filter((q) => result.answers[q.id] !== q.is_true);
  const mins = Math.floor(result.durationSec / 60);
  const secs = String(result.durationSec % 60).padStart(2, "0");
  const ans = (a: Answer) => (a === null ? "—" : a ? "Vero" : "Falso");

  return (
    <div className="min-h-screen pb-10">
      <AppBar back title={<Label2 it="Risultato" ur="نتیجہ" />} />
      <main className="mx-auto max-w-2xl space-y-5 p-4">
        <section className={cn("rounded-[20px] p-5 text-center text-on-brand animate-pop-in", passed ? "bg-course" : "bg-fail")}>
          {passed ? <Trophy className="mx-auto size-11" /> : <Frown className="mx-auto size-11" />}
          <p className="mt-2 text-[26px] font-black">
            {passed ? "PROMOSSO" : "BOCCIATO"} / <span className="font-urdu">{passed ? "کامیاب" : "ناکام"}</span>
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2.5">
            <ResultTile icon={<X className="size-4" />} label="Errori" ur="غلطیاں" value={`${result.errors} (max ${EXAM_MAX_ERRORS})`} />
            <ResultTile icon={<Clock className="size-4" />} label="Tempo" ur="وقت" value={`${mins}:${secs}`} />
          </div>
        </section>

        {wrong.length > 0 && (
          <h2 className="px-1 text-lg font-black">
            Domande sbagliate / <span className="font-urdu">غلط سوالات</span>
          </h2>
        )}
        {wrong.map((q) => (
          <AppCard key={q.id} className="space-y-2.5 p-4">
            <BilingualText it={q.text_it} ur={q.text_ur} className="font-extrabold" />
            <div className="flex flex-wrap gap-2">
              <Pill className="bg-falso/15 text-falso">Tua risposta: {ans(result.answers[q.id] ?? null)}</Pill>
              <Pill className="bg-vero/15 text-vero">Corretta: {q.is_true ? "Vero" : "Falso"}</Pill>
            </div>
            {q.explanation_it && <BilingualText it={q.explanation_it} ur={q.explanation_ur} className="text-sm font-semibold" />}
          </AppCard>
        ))}

        <div className="space-y-4 pt-2">
          <ChunkyButton onClick={onRetry}>Nuovo esame</ChunkyButton>
          <Link to="/" className={chunkyClass("navy")}>
            Home
          </Link>
        </div>
      </main>
    </div>
  );
}

function ResultTile({ icon, label, ur, value }: { icon: React.ReactNode; label: string; ur: string; value: string }) {
  return (
    <div className="rounded-[14px] bg-on-brand/15 px-2 py-3">
      <div className="flex items-center justify-center gap-1 text-xs font-extrabold">
        {icon}
        <Label2 it={label} ur={ur} />
      </div>
      <div className="mt-1 text-xl font-black">{value}</div>
    </div>
  );
}
