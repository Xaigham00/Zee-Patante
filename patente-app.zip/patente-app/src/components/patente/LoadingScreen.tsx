import { Loader2 } from "lucide-react";

export function LoadingScreen() {
  return (
    <div className="min-h-screen">
      <div className="h-14 bg-bar" />
      <div className="grid place-items-center pt-32 text-muted-foreground">
        <Loader2 className="size-8 animate-spin" />
      </div>
    </div>
  );
}
