import type { ButtonHTMLAttributes, ReactNode } from "react";
import { CheckCircle2, Circle, ListOrdered, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/language";
import { done, todo, type Stats } from "@/lib/progress";

/** Shows Italian and/or Urdu depending on the global language toggle. */
export function BilingualText({
  it,
  ur,
  className,
  urClassName,
}: {
  it: string;
  ur?: string | null;
  className?: string;
  urClassName?: string;
}) {
  const { showIt, showUr } = useLang();
  const hasUr = !!ur && ur.trim() !== "";
  return (
    <div className="space-y-1">
      {(showIt || !hasUr) && <p className={className}>{it}</p>}
      {showUr && hasUr && (
        <p lang="ur" dir="rtl" className={cn("urdu", className, urClassName)}>
          {ur}
        </p>
      )}
    </div>
  );
}

/** Small "Italian / Urdu" label that follows the toggle. */
export function Label2({ it, ur }: { it: string; ur: string }) {
  const { mode } = useLang();
  if (mode === "italian") return <>{it}</>;
  if (mode === "urdu") return <span className="font-urdu">{ur}</span>;
  return (
    <>
      {it} <span className="opacity-70">/</span> <span className="font-urdu">{ur}</span>
    </>
  );
}

type Tone = "vero" | "falso" | "navy";
const toneClass: Record<Tone, string> = {
  vero: "bg-vero edge-vero",
  falso: "bg-falso edge-falso",
  navy: "bg-navy-2 edge-navy",
};

export function chunkyClass(tone: Tone = "vero", className?: string) {
  return cn(
    "chunky flex w-full items-center justify-center gap-2 py-4 text-xl font-black tracking-wide text-on-brand disabled:cursor-default",
    toneClass[tone],
    className,
  );
}

export function ChunkyButton({
  tone = "vero",
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: Tone }) {
  return (
    <button type="button" {...props} className={chunkyClass(tone, className)}>
      {children}
    </button>
  );
}

export function Pill({
  children,
  className,
  icon,
}: {
  children: ReactNode;
  className?: string;
  icon?: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full bg-pill px-3 py-1.5 text-[13px] font-extrabold text-pill-foreground",
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}

export function AppCard({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("rounded-[18px] bg-card shadow-card", className)}>{children}</div>;
}

export function SoftProgress({ value, onDark }: { value: number; onDark?: boolean }) {
  const pct = Math.round(Math.min(1, Math.max(0, value)) * 100);
  return (
    <div
      className={cn("h-2 overflow-hidden rounded-full", onDark ? "bg-on-brand/25" : "bg-border")}
      role="progressbar"
      aria-valuenow={pct}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={cn("h-full rounded-full transition-all", onDark ? "bg-on-brand" : "bg-vero")}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function StatTile({
  icon,
  it,
  ur,
  value,
  toneClass,
  onDark,
}: {
  icon: ReactNode;
  it: string;
  ur: string;
  value: number;
  toneClass: string;
  onDark?: boolean | undefined;
}) {
  const { showIt } = useLang();
  return (
    <div
      className={cn(
        "flex flex-1 flex-col items-center rounded-xl px-1.5 py-2",
        onDark ? "bg-on-brand/15 text-on-brand" : "bg-tile",
      )}
    >
      <div className="flex items-center gap-1 text-[11px] font-extrabold">
        <span className={onDark ? "" : toneClass}>{icon}</span>
        <span className={cn("truncate", !showIt && "font-urdu")}>{showIt ? it : ur}</span>
      </div>
      <div className={cn("text-lg font-black", onDark ? "" : toneClass)}>{value}</div>
    </div>
  );
}

export function StatRow({ stats, onDark }: { stats: Stats; onDark?: boolean }) {
  const s = "size-3.5";
  return (
    <div className="flex gap-1.5">
      <StatTile onDark={onDark} toneClass="text-vero" icon={<CheckCircle2 className={s} />} it="Giuste" ur="درست" value={stats.correct} />
      <StatTile onDark={onDark} toneClass="text-falso" icon={<XCircle className={s} />} it="Sbagl." ur="غلط" value={stats.wrong} />
      <StatTile onDark={onDark} toneClass="text-muted-foreground" icon={<Circle className={s} />} it="Da fare" ur="باقی" value={todo(stats)} />
      <StatTile onDark={onDark} toneClass="text-navy-2" icon={<ListOrdered className={s} />} it="Totale" ur="کل" value={stats.total} />
    </div>
  );
}

export { done };
