import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck, Trophy } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Question } from "@/lib/content";
import { saveAnswer, toggleBookmark, useProgress } from "@/lib/progress";
import { AppBar } from "./AppBar";
import { QuestionCard } from "./QuestionCard";
import { ChunkyButton, Pill } from "./ui";

/** Practice mode: instant feedback + explanation after every answer. */
export function PracticeQuiz({ title, questions }: { title: string; questions: Question[] }) {
  const navigate = useNavigate();
  const progress = useProgress();
  const [i, setI] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [selected, setSelected] = useState<boolean | null>(null);
  const [finished, setFinished] = useState(false);

  const total = questions.length;
  const q = questions[Math.min(i, total - 1)] as Question;
  const bookmarked = progress.bookmarks.includes(q.id);

  const answer = (v: boolean) => {
    const ok = v === q.is_true;
    setSelected(v);
    if (ok) setCorrect((c) => c + 1);
    saveAnswer(q, ok);
  };

  const next = () => {
    if (i + 1 >= total) {
      setFinished(true);
      return;
    }
    setI(i + 1);
    setSelected(null);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="min-h-screen pb-28">
      <AppBar
        back
        title={title}
        progress={(i + 1) / total}
        actions={
          <>
            <Pill className="bg-on-brand/15 text-on-brand">
              {i + 1}/{total}
            </Pill>
            <button
              type="button"
              aria-label={bookmarked ? "Rimuovi segnalibro" : "Aggiungi segnalibro"}
              onClick={() => toggleBookmark(q.id)}
              className="grid size-10 place-items-center rounded-full hover:bg-on-brand/15"
            >
              {bookmarked ? <BookmarkCheck className="size-5" /> : <Bookmark className="size-5" />}
            </button>
          </>
        }
      />
      <main className="mx-auto max-w-2xl p-4">
        <QuestionCard
          key={q.id}
          q={q}
          label={`Domanda ${i + 1}/${total} · سوال`}
          selected={selected}
          reveal={selected !== null}
          onAnswer={answer}
        />
      </main>

      {selected !== null && (
        <div className="fixed inset-x-0 bottom-0 z-20 bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur">
          <div className="mx-auto max-w-2xl px-4 pt-2 pb-5">
            <ChunkyButton onClick={next}>{i + 1 >= total ? "Termina" : "Avanti / اگلا"}</ChunkyButton>
          </div>
        </div>
      )}

      <AlertDialog open={finished}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Trophy className="size-5 text-vero" /> Fine / <span className="font-urdu">ختم</span>
            </AlertDialogTitle>
            <AlertDialogDescription className="text-3xl font-black text-foreground">
              {correct} / {total}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => navigate({ to: "/" })}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
