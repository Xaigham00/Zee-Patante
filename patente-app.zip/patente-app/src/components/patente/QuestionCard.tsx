import { CheckCircle2, CircleDot, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { signLabelsQuery, signUrl, type Question } from "@/lib/content";
import { AppCard, BilingualText, ChunkyButton, Pill } from "./ui";

/**
 * Label pill, sign image, question text, big VERO / FALSO buttons
 * (+ explanation card in practice mode).
 */
export function QuestionCard({
  q,
  selected,
  reveal,
  onAnswer,
  label,
}: {
  q: Question;
  selected: boolean | null;
  reveal: boolean;
  onAnswer?: (v: boolean) => void;
  label?: string;
}) {
  const answered = reveal;
  const skipped = reveal && selected === null;
  const correct = selected === q.is_true;
  const img = signUrl(q.image);
  const { data: labels } = useQuery(signLabelsQuery);
  const signLabel = q.image ? labels?.[q.image] : undefined;

  const btn = (value: boolean) => {
    let dim = false;
    let mark: React.ReactNode = null;
    if (selected !== null || reveal) {
      if (reveal) {
        const isRight = value === q.is_true;
        dim = !isRight;
        if (isRight) mark = <CheckCircle2 className="size-6" />;
        else if (selected === value) mark = <XCircle className="size-6" />;
      } else {
        dim = selected !== value;
        if (selected === value) mark = <CircleDot className="size-6" />;
      }
    }
    return (
      <ChunkyButton
        tone={value ? "vero" : "falso"}
        className={cn(dim && (reveal ? "opacity-35" : "opacity-45"))}
        disabled={answered || !onAnswer}
        aria-pressed={selected === value}
        onClick={() => onAnswer?.(value)}
      >
        {mark}
        {value ? "VERO" : "FALSO"}
      </ChunkyButton>
    );
  };

  return (
    <div className="space-y-4 animate-pop-in">
      <AppCard className="p-4">
        {label && <Pill className="mb-3.5">{label}</Pill>}
        {img && (
          <div className="mb-4 flex justify-center">
            <div className="rounded-2xl border bg-sign-plate p-3">
              <img
                src={img}
                alt={signLabel?.label_it || "Segnale stradale"}
                className="h-[170px] w-auto object-contain"
              />
            </div>
          </div>
        )}
        {img && signLabel?.label_it && (
          <div className="-mt-2 mb-4 text-center">
            <BilingualText
              it={signLabel.label_it}
              ur={signLabel.label_ur}
              className="text-sm font-extrabold text-muted-foreground"
            />
          </div>
        )}
        <BilingualText it={q.text_it} ur={q.text_ur} className="text-xl font-extrabold leading-snug" />
        <div className="mt-6 grid grid-cols-2 gap-3 pb-1">
          {btn(true)}
          {btn(false)}
        </div>
      </AppCard>

      {answered && (
        <AppCard className={cn("border-2 p-4 animate-pop-in", correct ? "border-vero" : "border-falso")}>
          <div className={cn("mb-2.5 flex items-center gap-2 text-[17px] font-black", correct ? "text-vero" : "text-falso")}>
            {correct ? <CheckCircle2 className="size-5" /> : <XCircle className="size-5" />}
            {skipped ? (
              <span>
                Senza risposta / <span className="font-urdu">جواب نہیں دیا</span>
              </span>
            ) : correct ? (
              <span>
                Corretto / <span className="font-urdu">درست</span>
              </span>
            ) : (
              <span>
                Sbagliato / <span className="font-urdu">غلط</span>
              </span>
            )}
          </div>
          <BilingualText
            it={q.explanation_it ?? `Risposta: ${q.is_true ? "Vero" : "Falso"}`}
            ur={q.explanation_ur ?? `جواب: ${q.is_true ? "درست" : "غلط"}`}
            className="font-semibold"
          />
        </AppCard>
      )}
    </div>
  );
}
