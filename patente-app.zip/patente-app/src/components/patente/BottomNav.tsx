import { Link } from "@tanstack/react-router";
import { BookOpen, RotateCcw, Timer } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Argomenti", icon: BookOpen },
  { to: "/esame", label: "Esame", icon: Timer },
  { to: "/errori", label: "Errori", icon: RotateCcw },
] as const;

export function BottomNav({ active }: { active: "/" | "/esame" | "/errori" }) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 border-t bg-card pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto grid max-w-2xl grid-cols-3">
        {items.map(({ to, label, icon: Icon }) => {
          const on = active === to;
          return (
            <Link
              key={to}
              to={to}
              className="flex flex-col items-center gap-1 py-2.5 text-xs font-extrabold text-muted-foreground"
            >
              <span
                className={cn(
                  "grid h-8 w-16 place-items-center rounded-full transition-colors",
                  on && "bg-vero/15 text-vero",
                )}
              >
                <Icon className="size-5" />
              </span>
              <span className={cn(on && "text-foreground")}>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
