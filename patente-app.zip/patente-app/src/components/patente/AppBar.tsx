import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Languages } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { setLangMode, useLang, type LangMode } from "@/lib/language";

export function LanguageToggle() {
  const { mode } = useLang();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label="Language / زبان"
        className="grid size-10 place-items-center rounded-full text-on-brand transition-colors hover:bg-on-brand/15"
      >
        <Languages className="size-5" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-44">
        <DropdownMenuRadioGroup value={mode} onValueChange={(v) => setLangMode(v as LangMode)}>
          <DropdownMenuRadioItem value="italian">Italiano</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="urdu">
            <span className="font-urdu">اردو</span>
          </DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="both">
            Italiano + <span className="font-urdu">اردو</span>
          </DropdownMenuRadioItem>
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function AppBar({
  title,
  back,
  onBack,
  actions,
  progress,
}: {
  title: ReactNode;
  back?: boolean;
  onBack?: () => void;
  actions?: ReactNode;
  progress?: number;
}) {
  return (
    <header className="sticky top-0 z-30 bg-bar text-on-brand">
      <div className="mx-auto flex h-14 max-w-2xl items-center gap-1 px-2">
        {back &&
          (onBack ? (
            <button
              type="button"
              onClick={onBack}
              aria-label="Indietro"
              className="grid size-10 place-items-center rounded-full hover:bg-on-brand/15"
            >
              <ArrowLeft className="size-5" />
            </button>
          ) : (
            <Link
              to="/"
              aria-label="Indietro"
              className="grid size-10 place-items-center rounded-full hover:bg-on-brand/15"
            >
              <ArrowLeft className="size-5" />
            </Link>
          ))}
        <h1 className="min-w-0 flex-1 truncate px-2 text-xl font-extrabold">{title}</h1>
        <div className="flex items-center gap-1">
          {actions}
          <LanguageToggle />
        </div>
      </div>
      {progress !== undefined && (
        <div className="h-1.5 bg-on-brand/20">
          <div
            className="h-full bg-progress-glow transition-all"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>
      )}
    </header>
  );
}
