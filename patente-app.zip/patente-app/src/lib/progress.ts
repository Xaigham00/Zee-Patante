import { useSyncExternalStore } from "react";
import type { Answer } from "./exam";

/**
 * Per-device study progress (the original app kept this on the phone, with no account).
 * Stored in the browser: last result per question, bookmarks, and past exams.
 */
export type QuestionProgress = {
  chapterId: number;
  topicId?: number | null | undefined;
  attempts: number;
  correctCount: number;
  lastCorrect: boolean;
  lastAt: number;
};

export type ExamRecord = {
  takenAt: number;
  total: number;
  errors: number;
  passed: boolean;
  durationSec: number;
  answers: { questionId: number; answer: Answer; correct: boolean }[];
};

export type ProgressState = {
  questions: Record<number, QuestionProgress>;
  bookmarks: number[];
  exams: ExamRecord[];
};

export type Stats = { total: number; correct: number; wrong: number };

const KEY = "patente.progress.v1";
const EMPTY: ProgressState = { questions: {}, bookmarks: [], exams: [] };

let state: ProgressState = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    state = EMPTY;
  }
}

function commit(next: ProgressState) {
  state = next;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage full or blocked: keep in memory */
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  load();
  listeners.add(l);
  return () => listeners.delete(l);
}

function getSnapshot() {
  load();
  return state;
}

/** Current progress, for client-only loaders. */
export function readProgress(): ProgressState {
  return getSnapshot();
}

export function useProgress(): ProgressState {
  return useSyncExternalStore(subscribe, getSnapshot, () => EMPTY);
}

/** Pure update for one answer: attempts+1, correct counter, last result wins. */
export function applyAnswer(
  prev: ProgressState,
  questionId: number,
  chapterId: number,
  correct: boolean,
  now: number,
  topicId: number | null = null,
): ProgressState {
  const old = prev.questions[questionId];
  return {
    ...prev,
    questions: {
      ...prev.questions,
      [questionId]: {
        chapterId,
        topicId: topicId ?? old?.topicId ?? null,
        attempts: (old?.attempts ?? 0) + 1,
        correctCount: (old?.correctCount ?? 0) + (correct ? 1 : 0),
        lastCorrect: correct,
        lastAt: now,
      },
    },
  };
}

export function saveAnswer(
  q: { id: number; chapter_id: number; group_no: number | null },
  correct: boolean,
) {
  load();
  commit(applyAnswer(state, q.id, q.chapter_id, correct, Date.now(), q.group_no));
}

export function saveExam(
  record: ExamRecord,
  questions: { id: number; chapter_id: number; group_no: number | null }[],
) {
  load();
  let next: ProgressState = { ...state, exams: [record, ...state.exams].slice(0, 50) };
  const now = Date.now();
  for (const a of record.answers) {
    if (a.answer === null) continue; // only answered questions update practice progress
    const q = questions.find((x) => x.id === a.questionId);
    if (q) next = applyAnswer(next, q.id, q.chapter_id, a.correct, now, q.group_no);
  }
  commit(next);
}

export function toggleBookmark(questionId: number) {
  load();
  const has = state.bookmarks.includes(questionId);
  commit({
    ...state,
    bookmarks: has
      ? state.bookmarks.filter((id) => id !== questionId)
      : [...state.bookmarks, questionId],
  });
}

/** Questions whose LAST answer was wrong. */
export function mistakeIds(p: ProgressState): number[] {
  return Object.entries(p.questions)
    .filter(([, v]) => v.lastCorrect === false)
    .map(([k]) => Number(k));
}

/** correct / wrong = result of the last attempt of each question in the chapter. */
export function chapterStats(p: ProgressState, chapterId: number, total: number): Stats {
  let correct = 0;
  let wrong = 0;
  for (const v of Object.values(p.questions)) {
    if (v.chapterId !== chapterId) continue;
    if (v.lastCorrect) correct++;
    else wrong++;
  }
  return { total, correct, wrong };
}

/** Same as chapterStats, for one sub-topic. */
export function topicStats(p: ProgressState, topicId: number, total: number): Stats {
  let correct = 0;
  let wrong = 0;
  for (const v of Object.values(p.questions)) {
    if (v.topicId !== topicId) continue;
    if (v.lastCorrect) correct++;
    else wrong++;
  }
  return { total, correct, wrong };
}

export function sumStats(all: Stats[]): Stats {
  return all.reduce(
    (a, s) => ({ total: a.total + s.total, correct: a.correct + s.correct, wrong: a.wrong + s.wrong }),
    { total: 0, correct: 0, wrong: 0 },
  );
}

export const todo = (s: Stats) => Math.max(0, s.total - s.correct - s.wrong);
export const done = (s: Stats) => (s.total === 0 ? 0 : (s.correct + s.wrong) / s.total);
