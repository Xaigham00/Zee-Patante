import { describe, expect, it } from "vitest";
import { countErrors, EXAM_QUESTION_COUNT, EXAM_SECONDS, isPassed } from "./exam";
import { applyAnswer, chapterStats, mistakeIds, topicStats, type ProgressState } from "./progress";

describe("exam rules", () => {
  it("has 30 questions and 20 minutes", () => {
    expect(EXAM_QUESTION_COUNT).toBe(30);
    expect(EXAM_SECONDS).toBe(1200);
  });

  it("passes with 3 errors and fails with 4", () => {
    expect(isPassed(3)).toBe(true);
    expect(isPassed(4)).toBe(false);
  });

  it("counts unanswered questions as errors", () => {
    const qs = [
      { id: 1, is_true: true },
      { id: 2, is_true: false },
      { id: 3, is_true: true },
    ];
    expect(countErrors(qs, { 1: true, 2: null, 3: false })).toBe(2);
  });
});

describe("progress", () => {
  const empty: ProgressState = { questions: {}, bookmarks: [], exams: [] };

  it("uses the last answer of each question for chapter stats and mistakes", () => {
    let p = applyAnswer(empty, 10, 1, false, 1);
    p = applyAnswer(p, 10, 1, true, 2);
    p = applyAnswer(p, 11, 1, false, 3);
    expect(p.questions[10]?.attempts).toBe(2);
    expect(chapterStats(p, 1, 5)).toEqual({ total: 5, correct: 1, wrong: 1 });
    expect(mistakeIds(p)).toEqual([11]);
  });

  it("counts sub-topic stats only for questions of that sub-topic", () => {
    let p = applyAnswer(empty, 1, 8, true, 1, 4057);
    p = applyAnswer(p, 2, 8, false, 2, 4057);
    p = applyAnswer(p, 3, 8, false, 3, 4058);
    expect(topicStats(p, 4057, 14)).toEqual({ total: 14, correct: 1, wrong: 1 });
    expect(topicStats(p, 4058, 12)).toEqual({ total: 12, correct: 0, wrong: 1 });
  });
});
