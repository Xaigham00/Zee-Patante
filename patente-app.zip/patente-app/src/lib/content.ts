import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import signs from "@/assets/signs.json";

export type Question = {
  id: number;
  chapter_id: number;
  group_no: number | null;
  text_it: string;
  text_ur: string | null;
  is_true: boolean;
  image: string | null;
  explanation_it: string | null;
  explanation_ur: string | null;
};

export type ChapterOverview = {
  id: number;
  title_it: string;
  title_ur: string | null;
  sort_order: number;
  question_count: number;
  topic_count: number;
  images: string[];
};

/** A sub-topic of a chapter ("Quesito" group in the official list). */
export type Topic = {
  id: number;
  chapter_id: number;
  sort_order: number;
  title_it: string | null;
  title_ur: string | null;
  image: string | null;
  question_count: number;
};

const QUESTION_COLUMNS =
  "id, chapter_id, group_no, text_it, text_ur, is_true, image, explanation_it, explanation_ur";

export const chapterTopicsQuery = (chapterId: number) =>
  queryOptions({
    queryKey: ["chapter-topics", chapterId],
    staleTime: 1000 * 60 * 60,
    queryFn: async () => {
      const [{ data: chapter, error: e1 }, { data: topics, error: e2 }] = await Promise.all([
        supabase.from("chapters").select("id, title_it, title_ur, sort_order").eq("id", chapterId).maybeSingle(),
        supabase
          .from("topics")
          .select("id, chapter_id, sort_order, title_it, title_ur, image, question_count")
          .eq("chapter_id", chapterId)
          .order("sort_order"),
      ]);
      if (e1) throw e1;
      if (e2) throw e2;
      return { chapter, topics: (topics ?? []) as Topic[] };
    },
  });

export type TopicQuestions = { questions: Question[]; topics: Topic[] };

/** Questions of the given topics, topic by topic in the order given, in official order inside each. */
export const topicQuestionsQuery = (topicIds: number[]) =>
  queryOptions({
    queryKey: ["topic-questions", topicIds.join(",")],
    staleTime: 1000 * 60 * 60,
    queryFn: async (): Promise<TopicQuestions> => {
      const out: Question[] = [];
      for (let i = 0; i < topicIds.length; i += 50) {
        const ids = topicIds.slice(i, i + 50);
        for (let from = 0; ; from += 1000) {
          const { data, error } = await supabase
            .from("questions")
            .select(QUESTION_COLUMNS)
            .in("group_no", ids)
            .order("id")
            .range(from, from + 999);
          if (error) throw error;
          out.push(...((data ?? []) as Question[]));
          if (!data || data.length < 1000) break;
        }
      }
      const rank = new Map(topicIds.map((id, n) => [id, n]));
      const { data: topics, error } = await supabase
        .from("topics")
        .select("id, chapter_id, sort_order, title_it, title_ur, image, question_count")
        .in("id", topicIds);
      if (error) throw error;
      const sorted = [...out].sort(
        (a, b) => (rank.get(a.group_no ?? -1) ?? 0) - (rank.get(b.group_no ?? -1) ?? 0) || a.id - b.id,
      );
      return { questions: sorted, topics: (topics ?? []) as Topic[] };
    },
  });

const signMap = signs as Record<string, string>;
export function signUrl(image: string | null | undefined): string | null {
  if (!image) return null;
  return signMap[image] ?? null;
}

export type SignLabel = { label_it: string | null; label_ur: string | null };

/** Italian/Urdu names of the sign pictures, keyed by image filename. */
export const signLabelsQuery = queryOptions({
  queryKey: ["sign-labels"],
  staleTime: 1000 * 60 * 30,
  queryFn: async (): Promise<Record<string, SignLabel>> => {
    const { data, error } = await supabase.from("signs").select("image, label_it, label_ur").limit(2000);
    if (error) throw error;
    return Object.fromEntries((data ?? []).map((s) => [s.image, { label_it: s.label_it, label_ur: s.label_ur }]));
  },
});

export const chaptersQuery = queryOptions({
  queryKey: ["chapters"],
  staleTime: 1000 * 60 * 60,
  queryFn: async (): Promise<ChapterOverview[]> => {
    const { data, error } = await supabase.rpc("chapter_overview");
    if (error) throw error;
    return (data ?? []) as ChapterOverview[];
  },
});

export const chapterQuery = (chapterId: number) =>
  queryOptions({
    queryKey: ["chapter", chapterId],
    staleTime: 1000 * 60 * 60,
    queryFn: async () => {
      const [{ data: ch, error: e1 }, questions] = await Promise.all([
        supabase.from("chapters").select("id, title_it, title_ur").eq("id", chapterId).maybeSingle(),
        fetchAllQuestions(chapterId),
      ]);
      if (e1) throw e1;
      return { chapter: ch, questions };
    },
  });

async function fetchAllQuestions(chapterId: number): Promise<Question[]> {
  const out: Question[] = [];
  const page = 1000;
  for (let from = 0; ; from += page) {
    const { data, error } = await supabase
      .from("questions")
      .select(QUESTION_COLUMNS)
      .eq("chapter_id", chapterId)
      .order("id")
      .range(from, from + page - 1);
    if (error) throw error;
    out.push(...((data ?? []) as Question[]));
    if (!data || data.length < page) break;
  }
  return out;
}

export async function fetchQuestionsByIds(ids: number[]): Promise<Question[]> {
  const out: Question[] = [];
  for (let i = 0; i < ids.length; i += 200) {
    const { data, error } = await supabase
      .from("questions")
      .select(QUESTION_COLUMNS)
      .in("id", ids.slice(i, i + 200));
    if (error) throw error;
    out.push(...((data ?? []) as Question[]));
  }
  return out;
}

export async function fetchExamQuestions(count: number): Promise<Question[]> {
  const { data, error } = await supabase.rpc("random_questions", { n: count });
  if (error) throw error;
  return (data ?? []) as Question[];
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i] as T;
    a[i] = a[j] as T;
    a[j] = tmp;
  }
  return a;
}
