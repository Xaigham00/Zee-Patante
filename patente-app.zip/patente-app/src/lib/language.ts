import { useSyncExternalStore } from "react";

export type LangMode = "italian" | "urdu" | "both";

const KEY = "patente.lang";
let mode: LangMode = "both";
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  const v = window.localStorage.getItem(KEY);
  if (v === "italian" || v === "urdu" || v === "both") mode = v;
}

export function setLangMode(m: LangMode) {
  load();
  mode = m;
  try {
    window.localStorage.setItem(KEY, m);
  } catch {
    /* ignore */
  }
  listeners.forEach((l) => l());
}

export function useLang() {
  const m = useSyncExternalStore(
    (l) => {
      load();
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => {
      load();
      return mode;
    },
    () => "both" as LangMode,
  );
  return { mode: m, showIt: m !== "urdu", showUr: m !== "italian" };
}
