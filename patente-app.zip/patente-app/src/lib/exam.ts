/** Official patente B quiz rules, kept from the original app. */
export const EXAM_QUESTION_COUNT = 30;
export const EXAM_SECONDS = 20 * 60;
export const EXAM_MAX_ERRORS = 3;

export type Answer = boolean | null; // null = not answered

/** Unanswered questions count as errors. */
export function countErrors(
  questions: { id: number; is_true: boolean }[],
  answers: Record<number, Answer>,
): number {
  return questions.filter((q) => answers[q.id] !== q.is_true).length;
}

export function isPassed(errors: number): boolean {
  return errors <= EXAM_MAX_ERRORS;
}

export function formatClock(seconds: number): string {
  const s = Math.max(0, seconds);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
