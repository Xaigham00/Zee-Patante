// Server-only helpers for calling Lovable AI (OpenAI Responses through the Lovable AI Gateway).
import { createOpenAI } from "@ai-sdk/openai";
import { NoObjectGeneratedError, Output, streamText, type ModelMessage } from "ai";
import type { z } from "zod";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
export const TRANSLATE_MODEL = "openai/gpt-6-astra";
const RUN_ID_HEADER = "X-Lovable-AIG-Run-ID";

/** Resends the gateway-issued run id on follow-up calls of the same request; never mints one. */
function createRunIdFetch(initialRunId?: string) {
  let runId = initialRunId?.trim() || undefined;
  return async (input: RequestInfo | URL, init?: RequestInit) => {
    const headers = new Headers(init?.headers);
    if (runId && !headers.has(RUN_ID_HEADER)) headers.set(RUN_ID_HEADER, runId);
    const response = await fetch(input, { ...init, headers });
    runId ??= response.headers.get(RUN_ID_HEADER)?.trim() || undefined;
    return response;
  };
}

/** A typed error the UI can show as-is. `status` mirrors the gateway status (402, 403, 429…). */
export class AiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

function toAiError(e: unknown): AiError {
  if (e instanceof AiError) return e;
  const err = e as { statusCode?: number; status?: number; responseBody?: string; message?: string };
  const status = err?.statusCode ?? err?.status ?? 500;
  let message = err?.message ?? "Errore del traduttore";
  try {
    const body = err?.responseBody ? (JSON.parse(err.responseBody) as { message?: string; error?: { message?: string } }) : null;
    message = body?.message ?? body?.error?.message ?? message;
  } catch {
    // keep message
  }
  if (status === 402) message = message || "Crediti AI esauriti. Aggiungi crediti per continuare.";
  if (status === 429) message = "Troppe richieste: aspetta un momento e riprova.";
  return new AiError(message, status);
}

/** Streams a structured-output call and returns the parsed object. */
export async function generateStructured<T>(opts: {
  instructions: string;
  messages: ModelMessage[];
  schema: z.ZodType<T>;
  signal?: AbortSignal;
}): Promise<T> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new AiError("Traduttore non configurato (chiave AI mancante).", 401);
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: createRunIdFetch(),
  });
  try {
    const result = streamText({
      model: provider.responses(TRANSLATE_MODEL),
      instructions: opts.instructions,
      messages: opts.messages,
      output: Output.object({ schema: opts.schema }),
      ...(opts.signal ? { abortSignal: opts.signal } : {}),
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    });
    return (await result.output) as T;
  } catch (e) {
    if (NoObjectGeneratedError.isInstance(e)) {
      throw new AiError("Il traduttore ha restituito una risposta non valida. Riprova.", 502);
    }
    throw toAiError(e);
  }
}
