import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import signs from "@/assets/signs.json";

type Ctx = { supabase: import("@supabase/supabase-js").SupabaseClient<import("@/integrations/supabase/types").Database>; userId: string };

/** Result shape for every translator call: errors are returned, not thrown, so the UI can show them. */
export type TranslatorResult<T> = { ok: true; data: T } | { ok: false; error: string; status: number };

async function isAdmin({ supabase, userId }: Ctx) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error) throw new Error("Impossibile verificare i permessi");
  return data === true;
}

const forbidden = { ok: false as const, error: "Solo l'amministratore può usare il traduttore.", status: 403 };

const GLOSSARY = {
  stop: "اسٹاپ",
  precedenza: "ترجیح / راستے کا حق (Precedenza)",
  sorpasso: "اوورٹیک (Sorpasso)",
  "centro abitato": "آبادی والا علاقہ (Centro abitato)",
  "distanza di sicurezza": "حفاظتی فاصلہ",
  patente: "ڈرائیونگ لائسنس (Patente)",
  carreggiata: "سڑک کا چلنے والا حصہ (Carreggiata)",
  incrocio: "چوراہا (Incrocio)",
  semaforo: "ٹریفک سگنل (Semaforo)",
  divieto: "ممانعت",
  obbligo: "لازمی ہدایت",
};

const BASE_RULES = `You are an expert Italian driving instructor (autoscuola) and a professional Italian-to-Urdu translator helping Urdu-speaking learners pass the Italian patente B theory exam.
Rules:
- Use simple, everyday Urdu in Urdu script.
- For road signs and technical terms put the Italian term in brackets the first time, e.g. اوورٹیک (sorpasso). Follow the glossary when a term appears.
- Do NOT cite article numbers or exact figures unless you are certain; prefer the general rule.
Glossary (Italian -> Urdu): ${JSON.stringify(GLOSSARY)}`;

/** Whether the signed-in user may use the translator. */
export const getTranslatorAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.auth.getUser();
    return { isAdmin: await isAdmin(context), email: data.user?.email ?? null, userId: context.userId };
  });

/** Free-text box: type Italian, get Urdu back (nothing is saved). */
export const quickTranslate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { text: string }) => ({ text: String(input.text ?? "").slice(0, 4000) }))
  .handler(async ({ data, context }): Promise<TranslatorResult<{ urdu: string }>> => {
    if (!(await isAdmin(context))) return forbidden;
    if (!data.text.trim()) return { ok: false, error: "Scrivi un testo in italiano.", status: 400 };
    const { generateStructured, AiError } = await import("./ai-gateway.server");
    try {
      const out = await generateStructured({
        instructions: `${BASE_RULES}\nTranslate the user's Italian text into Urdu. Keep the exact meaning.`,
        messages: [{ role: "user", content: data.text }],
        schema: z.object({ urdu: z.string() }),
      });
      return { ok: true, data: { urdu: out.urdu } };
    } catch (e) {
      const err = e instanceof AiError ? e : new AiError("Errore del traduttore", 500);
      console.error("quickTranslate failed", e);
      return { ok: false, error: err.message, status: err.status };
    }
  });

const signMap = signs as Record<string, string>;
const MAX_PER_CALL = 18;

/**
 * Translate one sub-topic: fills Urdu question text, Italian + Urdu explanations,
 * and the Italian + Urdu name of each sign picture that has none yet. Saves into the app.
 */
export const translateTopic = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { topicId: number; overwrite?: boolean }) => ({
    topicId: Number(input.topicId),
    overwrite: input.overwrite === true,
  }))
  .handler(
    async ({ data, context }): Promise<TranslatorResult<{ questions: number; signs: number }>> => {
      if (!(await isAdmin(context))) return forbidden;
      const { supabase } = context;
      const { data: qs, error } = await supabase
        .from("questions")
        .select("id, chapter_id, text_it, is_true, image, text_ur, explanation_ur")
        .eq("group_no", data.topicId)
        .order("id");
      if (error) return { ok: false, error: "Impossibile leggere le domande", status: 500 };
      if (!qs?.length) return { ok: true, data: { questions: 0, signs: 0 } };

      const todo = data.overwrite ? qs : qs.filter((q) => !q.text_ur?.trim() || !q.explanation_ur?.trim());
      const images = [...new Set(qs.map((q) => q.image).filter((i): i is string => !!i))];
      const { data: existing } = images.length
        ? await supabase.from("signs").select("image, label_it, label_ur").in("image", images)
        : { data: [] as { image: string; label_it: string | null; label_ur: string | null }[] };
      const labelled = new Set(
        (existing ?? []).filter((s) => s.label_it?.trim() && s.label_ur?.trim()).map((s) => s.image),
      );
      const signTodo = data.overwrite ? images : images.filter((i) => !labelled.has(i));
      if (!todo.length && !signTodo.length) return { ok: true, data: { questions: 0, signs: 0 } };

      const [{ data: chapter }, { data: topic }] = await Promise.all([
        supabase.from("chapters").select("title_it").eq("id", qs[0]!.chapter_id).maybeSingle(),
        supabase.from("topics").select("title_it").eq("id", data.topicId).maybeSingle(),
      ]);

      const { generateStructured, AiError } = await import("./ai-gateway.server");
      const schema = z.object({
        questions: z.array(
          z.object({ id: z.number(), text_ur: z.string(), explanation_it: z.string(), explanation_ur: z.string() }),
        ),
        signs: z.array(z.object({ image: z.string(), label_it: z.string(), label_ur: z.string() })),
      });
      const instructions = `${BASE_RULES}
For each true/false question produce:
- text_ur: a clear, natural Urdu translation of the question. Keep the exact meaning (never turn a true statement into a false one or vice versa).
- explanation_it: 1-3 short sentences in simple Italian explaining WHY the given answer (is_true) is correct, based on the Italian Codice della Strada. It must agree with is_true.
- explanation_ur: the same explanation in simple Urdu.
For each sign picture listed under "signs_to_name" produce:
- label_it: the official short Italian name of the road sign (e.g. "Curva pericolosa a destra"), using the picture and the questions about it.
- label_ur: that name in Urdu.
Return one entry per question id and per sign image given, using the exact ids and image names.`;

      let savedQ = 0;
      let savedS = 0;
      try {
        const batches: (typeof todo)[] = [];
        for (let i = 0; i < Math.max(todo.length, 1); i += MAX_PER_CALL) batches.push(todo.slice(i, i + MAX_PER_CALL));
        for (const [bi, batch] of batches.entries()) {
          const signsHere = bi === 0 ? signTodo : [];
          if (!batch.length && !signsHere.length) continue;
          const payload = {
            chapter: chapter?.title_it ?? "",
            topic: topic?.title_it ?? "",
            questions: batch.map((q) => ({ id: q.id, text_it: q.text_it, is_true: q.is_true, sign: q.image })),
            signs_to_name: signsHere.map((img) => ({
              image: img,
              questions_about_it: qs.filter((q) => q.image === img).slice(0, 4).map((q) => q.text_it),
            })),
          };
          const content: ({ type: "text"; text: string } | { type: "image"; image: URL })[] = [
            { type: "text", text: JSON.stringify(payload) },
          ];
          for (const img of signsHere.length ? signsHere : [...new Set(batch.map((q) => q.image).filter(Boolean))]) {
            const url = img ? signMap[img] : undefined;
            if (url) {
              content.push({ type: "text", text: `Picture for sign "${img}":` });
              content.push({ type: "image", image: new URL(url) });
            }
          }
          const out = await generateStructured({ instructions, messages: [{ role: "user", content }], schema });

          const allowed = new Set(batch.map((q) => q.id));
          const rows = out.questions.filter((r) => allowed.has(r.id) && r.text_ur.trim() && r.explanation_ur.trim());
          const results = await Promise.all(
            rows.map((r) =>
              supabase
                .from("questions")
                .update({
                  text_ur: r.text_ur.trim(),
                  explanation_it: r.explanation_it.trim(),
                  explanation_ur: r.explanation_ur.trim(),
                })
                .eq("id", r.id),
            ),
          );
          savedQ += results.filter((r) => !r.error).length;

          const signRows = out.signs
            .filter((s) => signsHere.includes(s.image) && s.label_it.trim() && s.label_ur.trim())
            .map((s) => ({
              image: s.image,
              label_it: s.label_it.trim(),
              label_ur: s.label_ur.trim(),
              updated_at: new Date().toISOString(),
            }));
          if (signRows.length) {
            const { error: se } = await supabase.from("signs").upsert(signRows, { onConflict: "image" });
            if (!se) savedS += signRows.length;
            else console.error("sign save failed", se);
          }
        }
        return { ok: true, data: { questions: savedQ, signs: savedS } };
      } catch (e) {
        const err = e instanceof AiError ? e : new AiError("Errore del traduttore", 500);
        console.error("translateTopic failed", e);
        return { ok: false, error: err.message, status: err.status };
      }
    },
  );

/** Manual correction of one question's Urdu text / explanations. */
export const saveQuestionTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: { id: number; text_ur: string; explanation_it: string; explanation_ur: string }) => ({
      id: Number(input.id),
      text_ur: String(input.text_ur ?? "").slice(0, 4000),
      explanation_it: String(input.explanation_it ?? "").slice(0, 4000),
      explanation_ur: String(input.explanation_ur ?? "").slice(0, 4000),
    }),
  )
  .handler(async ({ data, context }): Promise<TranslatorResult<null>> => {
    if (!(await isAdmin(context))) return forbidden;
    const { error } = await context.supabase
      .from("questions")
      .update({
        text_ur: data.text_ur.trim() || null,
        explanation_it: data.explanation_it.trim() || null,
        explanation_ur: data.explanation_ur.trim() || null,
      })
      .eq("id", data.id);
    if (error) return { ok: false, error: "Salvataggio non riuscito", status: 500 };
    return { ok: true, data: null };
  });

/** Manual correction of a sign's name. */
export const saveSignLabel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { image: string; label_it: string; label_ur: string }) => ({
    image: String(input.image ?? ""),
    label_it: String(input.label_it ?? "").slice(0, 300),
    label_ur: String(input.label_ur ?? "").slice(0, 300),
  }))
  .handler(async ({ data, context }): Promise<TranslatorResult<null>> => {
    if (!(await isAdmin(context))) return forbidden;
    if (!signMap[data.image]) return { ok: false, error: "Segnale sconosciuto", status: 400 };
    const { error } = await context.supabase.from("signs").upsert(
      {
        image: data.image,
        label_it: data.label_it.trim() || null,
        label_ur: data.label_ur.trim() || null,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "image" },
    );
    if (error) return { ok: false, error: "Salvataggio non riuscito", status: 500 };
    return { ok: true, data: null };
  });
