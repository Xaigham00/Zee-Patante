# Patente B — Quiz in italiano e urdu

Preparazione all'esame teorico della patente B: 25 capitoli, 7.147 domande VERO/FALSO,
sotto-argomenti, esame simulato (30 domande, 20 minuti, massimo 3 errori) e supporto in
lingua urdu.

App web mobile-first costruita con TanStack Start (React 19 + Vite 8 + Tailwind CSS 4).

## Requisiti

- Node.js 20+ (oppure Bun)
- npm (oppure `bun`)

## Installazione

```sh
npm install
npm run dev
```

Apri http://localhost:8080

## Comandi

| Comando | Cosa fa |
| --- | --- |
| `npm run dev` | avvia l'app in sviluppo |
| `npm run build` | build di produzione |
| `npm run preview` | serve la build di produzione |
| `npm run test` | esegue i test (Vitest) |
| `npm run lint` | ESLint |
| `npm run format` | Prettier |

## Variabili d'ambiente

`.env` contiene l'URL del backend e la chiave **publishable** (è pubblica per progetto:
viene spedita nel bundle del browser). I secret veri (chiave di servizio, `LOVABLE_API_KEY`)
non sono nel repository: vengono gestiti da Lovable Cloud / Secrets.

## Database

I contenuti (capitoli, domande, sotto-argomenti, nomi dei segnali) stanno in un database
relazionale con tabelle in lettura pubblica; i progressi dello studente restano nel browser.

- `drizzle/schema.ts` — definizione delle tabelle
- `drizzle/migrations/` — SQL per ricreare lo schema (`0000` contenuti, `0001` sotto-argomenti,
  `0002` ruoli admin e traduzione dei segnali)
- `src/assets/signs.json` — mappa `nome file -> URL` delle immagini dei segnali (asset su CDN,
  non nel repository)

## Struttura

```
src/
  routes/        home, capitolo/$chapterId, quiz, esame, errori
  components/    patente/ (UI dell'app) e ui/ (primitive shadcn)
  lib/           content.ts (query), progress.ts (browser storage),
                 language.ts (italiano/urdu), exam.ts (regole d'esame)
  integrations/  client del backend
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
