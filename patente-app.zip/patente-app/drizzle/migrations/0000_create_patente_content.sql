CREATE TABLE public.chapters (
  id INTEGER PRIMARY KEY,
  title_it TEXT NOT NULL,
  title_ur TEXT,
  sort_order INTEGER NOT NULL
);
GRANT SELECT ON public.chapters TO anon, authenticated;
GRANT ALL ON public.chapters TO service_role;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Chapters are public" ON public.chapters FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.lessons (
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL REFERENCES public.chapters(id),
  title_it TEXT NOT NULL,
  title_ur TEXT,
  body_it TEXT NOT NULL,
  body_ur TEXT,
  sort_order INTEGER NOT NULL
);
GRANT SELECT ON public.lessons TO anon, authenticated;
GRANT ALL ON public.lessons TO service_role;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Lessons are public" ON public.lessons FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.questions (
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL REFERENCES public.chapters(id),
  group_no INTEGER,
  text_it TEXT NOT NULL,
  text_ur TEXT,
  is_true BOOLEAN NOT NULL,
  image TEXT,
  explanation_it TEXT,
  explanation_ur TEXT
);
CREATE INDEX idx_q_chapter ON public.questions(chapter_id);
GRANT SELECT ON public.questions TO anon, authenticated;
GRANT ALL ON public.questions TO service_role;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Questions are public" ON public.questions FOR SELECT TO anon, authenticated USING (true);

-- Chapter list with question counts and up to 4 sign images for the banners.
CREATE OR REPLACE FUNCTION public.chapter_overview()
RETURNS TABLE (id INTEGER, title_it TEXT, title_ur TEXT, sort_order INTEGER, question_count INTEGER, images TEXT[])
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT c.id, c.title_it, c.title_ur, c.sort_order,
    (SELECT count(*)::int FROM questions q WHERE q.chapter_id = c.id),
    COALESCE((
      SELECT array_agg(img ORDER BY first_id) FROM (
        SELECT q.image AS img, min(q.id) AS first_id
        FROM questions q
        WHERE q.chapter_id = c.id AND q.image IS NOT NULL AND q.image <> ''
        GROUP BY q.image ORDER BY min(q.id) LIMIT 4
      ) s
    ), ARRAY[]::text[])
  FROM chapters c
  ORDER BY c.sort_order;
$$;

-- Exam: N random questions.
CREATE OR REPLACE FUNCTION public.random_questions(n INTEGER DEFAULT 30)
RETURNS SETOF public.questions
LANGUAGE sql VOLATILE SECURITY INVOKER SET search_path = public
AS $$
  SELECT * FROM questions ORDER BY random() LIMIT LEAST(GREATEST(n, 1), 100);
$$;

GRANT EXECUTE ON FUNCTION public.chapter_overview() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.random_questions(INTEGER) TO anon, authenticated;