CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read their own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

-- Sign names shown under each road-sign picture (keyed by image filename).
CREATE TABLE public.signs (
  image text PRIMARY KEY,
  label_it text,
  label_ur text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.signs TO anon, authenticated;
GRANT INSERT, UPDATE ON public.signs TO authenticated;
GRANT ALL ON public.signs TO service_role;
ALTER TABLE public.signs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signs are public" ON public.signs FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Admins can add signs" ON public.signs FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can edit signs" ON public.signs FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admins may fill in the Urdu text and explanations of questions (only those columns).
GRANT UPDATE (text_ur, explanation_it, explanation_ur) ON public.questions TO authenticated;
CREATE POLICY "Admins can edit question translations" ON public.questions FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Translation progress per sub-topic of a chapter, and per chapter.
CREATE OR REPLACE FUNCTION public.topic_translation_status(_chapter_id integer)
RETURNS TABLE(topic_id integer, total integer, done integer)
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT q.group_no, count(*)::int,
    count(*) FILTER (WHERE coalesce(q.text_ur, '') <> '' AND coalesce(q.explanation_ur, '') <> '')::int
  FROM public.questions q
  WHERE q.chapter_id = _chapter_id
  GROUP BY q.group_no
$$;

CREATE OR REPLACE FUNCTION public.chapter_translation_status()
RETURNS TABLE(chapter_id integer, total integer, done integer)
LANGUAGE sql
STABLE
SET search_path = public
AS $$
  SELECT q.chapter_id, count(*)::int,
    count(*) FILTER (WHERE coalesce(q.text_ur, '') <> '' AND coalesce(q.explanation_ur, '') <> '')::int
  FROM public.questions q
  GROUP BY q.chapter_id
$$;