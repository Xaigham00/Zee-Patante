CREATE TABLE public.topics (
  id INTEGER PRIMARY KEY,
  chapter_id INTEGER NOT NULL REFERENCES public.chapters(id),
  sort_order INTEGER NOT NULL,
  title_it TEXT,
  title_ur TEXT,
  image TEXT,
  question_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_topics_chapter ON public.topics(chapter_id, sort_order);
GRANT SELECT ON public.topics TO anon, authenticated;
GRANT ALL ON public.topics TO service_role;
ALTER TABLE public.topics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Topics are public" ON public.topics FOR SELECT TO anon, authenticated USING (true);

CREATE INDEX idx_q_group ON public.questions(group_no);

DROP FUNCTION IF EXISTS public.chapter_overview();
CREATE FUNCTION public.chapter_overview()
RETURNS TABLE (id INTEGER, title_it TEXT, title_ur TEXT, sort_order INTEGER, question_count INTEGER, topic_count INTEGER, images TEXT[])
LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$
  SELECT c.id, c.title_it, c.title_ur, c.sort_order,
    (SELECT count(*)::int FROM questions q WHERE q.chapter_id = c.id),
    (SELECT count(*)::int FROM topics t WHERE t.chapter_id = c.id),
    COALESCE((
      SELECT array_agg(img ORDER BY first_id) FROM (
        SELECT q.image AS img, min(q.id) AS first_id
        FROM questions q
        WHERE q.chapter_id = c.id AND q.image IS NOT NULL AND q.image <> ''
        GROUP BY q.image ORDER BY min(q.id) LIMIT 4
      ) s
    ), ARRAY[]::text[])
  FROM chapters c
  ORDER BY c.sort_order;
$$;
GRANT EXECUTE ON FUNCTION public.chapter_overview() TO anon, authenticated;