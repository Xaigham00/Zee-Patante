<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Quiz content (chapters, lessons, questions) lives in the Cloud database as public read-only tables; the app never writes to them. Why: content is shared and updated centrally.
- Study progress, bookmarks, exam history and language choice are stored in browser storage via `src/lib/progress.ts` / `src/lib/language.ts` (useSyncExternalStore). Why: the source app had no accounts and kept this per device.
- Road sign images are Lovable CDN assets mapped by filename in `src/assets/signs.json`; `questions.image` stores the filename. Why: keeps 400+ binaries out of the repo.
- Each chapter is split into sub-topics (`topics` table, id = `questions.group_no`, the official "Quesito" groups); chapter page lists topics, `/quiz?t=<ids>` shows all their questions as one scrolling list. Why: mirrors the official question list.
- Quiz/exam/mistakes routes use `ssr: false` because they shuffle questions or read browser storage.
- Exam rule constants live in `src/lib/exam.ts` and are covered by `src/lib/exam.test.ts`.
